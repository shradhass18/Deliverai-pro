import { db, auth } from "../lib/firebase";
import { collection, query, where, getDocs, doc, setDoc, deleteDoc, writeBatch } from "firebase/firestore";
import { Deliverable } from "../types";

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const DELIVERABLES_COLLECTION = "deliverables";

/**
 * Fetches all deliverables from Firestore owned by a specific user, sorted by creation date.
 */
export async function fetchDeliverablesFromFirestore(userId: string): Promise<Deliverable[]> {
  try {
    const q = query(
      collection(db, DELIVERABLES_COLLECTION),
      where("ownerId", "==", userId)
    );
    
    const snapshot = await getDocs(q);
    const deliverables: Deliverable[] = [];
    
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      deliverables.push({
        id: docSnap.id,
        inputText: data.inputText || "",
        deliverableType: data.deliverableType || "report",
        tone: data.tone || "professional",
        professional: data.professional || "",
        executive: data.executive || "",
        academic: data.academic || "",
        createdAt: data.createdAt || new Date().toISOString(),
        summary: data.summary || "",
        qualityScores: data.qualityScores || { readability: 90, professionalism: 90, completeness: 90, clarity: 90 },
        productivityInsights: data.productivityInsights || {
          estimatedTimeSavedMinutes: 30,
          tasksIdentified: [],
          deadlinesFound: [],
          decisionsExtracted: []
        },
        file: data.file || undefined
      });
    });

    // Safely sort in JavaScript by parsed date string (descending)
    return deliverables.sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, DELIVERABLES_COLLECTION);
  }
}

/**
 * Saves a single deliverable to Firestore, maintaining sync across deliverables and history collections.
 */
export async function saveDeliverableToFirestore(userId: string, deliverable: Deliverable): Promise<void> {
  try {
    // 1. Save to deliverables collection
    const docRef = doc(db, DELIVERABLES_COLLECTION, deliverable.id);
    await setDoc(docRef, {
      ...deliverable,
      ownerId: userId,
      updatedAt: new Date().toISOString()
    });

    // 2. Save to history collection
    const historyDocRef = doc(db, "history", `hist-${deliverable.id}`);
    await setDoc(historyDocRef, {
      id: `hist-${deliverable.id}`,
      ownerId: userId,
      deliverableId: deliverable.id,
      uid: userId,
      name: auth.currentUser?.displayName || "Shradha CSG",
      email: auth.currentUser?.email || "shradhacsg05@gmail.com",
      deliverableType: deliverable.deliverableType,
      generatedOutput: deliverable.professional || deliverable.executive || deliverable.academic || "",
      inputText: deliverable.inputText,
      summary: deliverable.summary,
      timestamp: deliverable.createdAt || new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${DELIVERABLES_COLLECTION}/${deliverable.id}`);
  }
}

/**
 * Deletes a single deliverable by ID from Firestore, keeping the deliverables and history synchronized.
 */
export async function deleteDeliverableFromFirestore(deliverableId: string): Promise<void> {
  try {
    // 1. Delete from deliverables collection
    const docRef = doc(db, DELIVERABLES_COLLECTION, deliverableId);
    await deleteDoc(docRef);

    // 2. Delete from history collection
    const historyDocRef = doc(db, "history", `hist-${deliverableId}`);
    await deleteDoc(historyDocRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${DELIVERABLES_COLLECTION}/${deliverableId}`);
  }
}

/**
 * Seeds Firestore with initial sample data if the user's history is empty.
 */
export async function seedUserIfEmpty(userId: string): Promise<Deliverable[]> {
  try {
    const existing = await fetchDeliverablesFromFirestore(userId);
    if (existing.length > 0) {
      return existing;
    }

    // Seed data
    const seed1: Deliverable = {
      id: `seed-1-${userId}`,
      inputText: "Sync on the DeliverAI product launch for early Q3. We need developers to finalize the landing page and finish integration of Google GenAI SDK by June 28. Then marketing will initiate ad campaigns starting July 5. Budget cap is $45,000. Sarah to coordinate testing, John to write the backend, and Dave will set up cloud infrastructure.",
      deliverableType: "report",
      tone: "professional",
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      professional: `## Project Launch Report: DeliverAI Pro (Q3 Launch)

### 1. Executive Summary
This report formalizes the tactical execution path for the upcoming launch of DeliverAI Pro in early Q3. It defines the core technical milestones, marketing scheduling constraints, and resource allocation boundaries to ensure a seamless market launch.

### 2. Strategic Objectives
*   **Engineering Completion**: Integrate Google GenAI SDK and fully configure server-side execution pathways.
*   **Web Ingress UI**: Code and polish the user-facing web applications.
*   **Budget Ceiling Compliance**: Strictly maintain budget allocations within the **$45,000 USD** threshold.

### 3. Resource & Team Routing
*   **Dave**: Provisioning secure Google Cloud / Firebase server environments.
*   **John**: Building the custom Express/Vite proxy API backend.
*   **Sarah**: Conducting complete end-to-end integration and load testing.

[CHART_START:bar:Budget Allocation Breakdown]
Infrastructure Setup: 12000
Software Licenses: 5000
Development Sprints: 20000
Marketing Campaigns: 8000
[CHART_END]

[FLOW_START:DeliverAI Launch Milestones]
Step 1: Engineering Lock | John completes backend and GenAI SDK integration by June 28
Step 2: Security Validation | Dave deploys server containers and verifies Firestore security rules by June 30
Step 3: Marketing Launch | Run initial search and social ad campaigns by July 5
[FLOW_END]

[REVISION_START:Immediate Launch Checklist]
- Finish integration of Google GenAI SDK by June 28
- Ensure lander elements render correctly for standard mobile viewports
- Deploy reverse proxy listening exclusively on port 3000
[REVISION_END]`,
      executive: `### BLUF (Bottom Line Up Front)
DeliverAI Pro is scheduled for an early Q3 launch with a maximum budget cap of **$45,000**. Critical dependencies are engineering completions by **June 28** and marketing initialization by **July 5**.

### Key Actions
*   **GenAI Integration**: John finalizing backend logic under strict timelines.
*   **Cloud Operations**: Dave preparing database and firewall environments.
*   **Quality Assurance**: Sarah executing user walkthrough testing.`,
      academic: `## Contextual Analysis: Rapid Prototyping & Generative Systems
This study reviews the technical mechanics deployed to scale the DeliverAI Pro generative middleware ecosystem. It details the utilization of the @google/genai module for parsing raw input, extracting key intents, and executing tone adjustments.

### Key Concepts Definitions
*   **Generative Middleware**: Intermediate server instances designed to buffer and scrub telemetry before making queries to Large Language Models.
*   **Multi-Modal Injection**: The capacity of neural networks to simultaneously process audio files and unstructured strings to form an integrated vector.`,
      qualityScores: {
        readability: 92,
        professionalism: 96,
        completeness: 88,
        clarity: 90
      },
      productivityInsights: {
        estimatedTimeSavedMinutes: 120,
        tasksIdentified: [
          "Finalize main landing page layouts",
          "Integrate official Google GenAI SDK on server endpoints",
          "Initialize marketing ad campaigns"
        ],
        deadlinesFound: [
          "June 28: Complete development and integration",
          "July 5: Initiate ad campaigns"
        ],
        decisionsExtracted: [
          "Launch target set for early Q3",
          "Approve budget ceiling at $45,000 USD",
          "Agree to use standard Express, Vite, and node for scaling"
        ]
      },
      summary: "DeliverAI Pro Q3 product launching sync overview defining milestones, budget caps, and marketing ad scheduling."
    };

    const seed2: Deliverable = {
      id: `seed-2-${userId}`,
      inputText: "Marketing brainstorm: Create a friendly, corporate announcement email introducing the new automated HR benefit cards. We are rolling out GymPass and Headspace free for all employees. It goes live on August 1st. Please click the link to register before July 15th so we can forecast cost.",
      deliverableType: "email",
      tone: "friendly",
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      professional: `Subject: Introducing Your New Wellness Benefits: Free GymPass & Headspace!

Dear Team,

We are absolutely thrilled to share a new addition to our employee care program designed to support your physical and emotional well-being!

Starting **August 1st**, all full-time employees will gain complimentary, full access to **GymPass** and the **Headspace** meditation platform. 

### What is Included?
1.  **GymPass**: Premium access to a global network of thousands of yoga classes, fitness studios, weight gyms, and sports clubs.
2.  **Headspace Premium**: Complete unlock of the guided sleep aids, stress management modules, and focusing audio streams.

### Required Employee Action
To ensure our financial forecasting is optimized for licensing, we kindly ask everyone to submit their enrollment registrations no later than **Friday, July 15th**.

Please click here to confirm your wellness card activation.

In wellness,  
Your People Operations Team`,
      executive: `Subject: HR Benefit Rollout: Access Free GymPass & Headspace starting August 1st

### BLUF
Complimentary corporate wellness licenses for GymPass and Headspace go live on **August 1st**. Actions required before **July 15th**.

### Actions Needed
1. Review the HR Portal registration page.
2. Complete signup by **July 15** to secure your account licenses.`,
      academic: `## Analytical Review: Cognitive Restructuring & Health Incentives
This study note evaluates the impacts of systematic corporate wellness incentives on overall occupational health metrics, exploring how platforms like GymPass and mindfulness suites like Headspace impact corporate productivity.

### Theoretical Pillars
*   **Preventative Biomechanics**: Enhancing physical resilience lowers workplace injury rates and boosts workplace satisfaction.
*   **Mindfulness Intervention**: Short, systematic meditation loops have been proven empirically to decrease anxiety metrics.`,
      qualityScores: {
        readability: 98,
        professionalism: 92,
        completeness: 95,
        clarity: 97
      },
      productivityInsights: {
        estimatedTimeSavedMinutes: 45,
        tasksIdentified: [
          "Register for enrollment in GymPass and Headspace programs",
          "Forecast employee wellness card licensing expenditures"
        ],
        deadlinesFound: [
          "July 15: Registration deadline for employees",
          "August 1: Live kickoff of wellness benefits"
        ],
        decisionsExtracted: [
          "Roll out free GymPass and Headspace licenses",
          "Finance wellness licenses directly from corporate People Operations budget"
        ]
      },
      summary: "HR team announcement outlining GymPass and Headspace benefits, enrollment deadlines, and registration URLs."
    };

    await saveDeliverableToFirestore(userId, seed1);
    await saveDeliverableToFirestore(userId, seed2);
    
    return [seed1, seed2];
  } catch (error) {
    console.error("Error seeding user in Firestore:", error);
    return [];
  }
}
