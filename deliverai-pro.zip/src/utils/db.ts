import { Deliverable } from "../types";

const LOCAL_STORAGE_KEY = "deliverai_pro_deliverables_v1";

const SEED_DELIVERABLES: Deliverable[] = [
  {
    id: "seed-1",
    inputText: "Sync on the DeliverAI product launch for early Q3. We need developers to finalize the landing page and finish integration of Google GenAI SDK by June 28. Then marketing will initiate ad campaigns starting July 5. Budget cap is $45,000. Sarah to coordinate testing, John to write the backend, and Dave will set up cloud infrastructure.",
    deliverableType: "report",
    tone: "professional",
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
    professional: `## Project Launch Report: DeliverAI Pro (Q3 Launch)

### 1. Executive Summary
This report formalizes the tactical execution path for the upcoming launch of DeliverAI Pro in early Q3. It defines the core technical milestones, marketing scheduling constraints, and resource allocation boundaries to ensure a seamless market launch.

### 2. Strategic Objectives
*   **Engineering Completion**: Integrate Google GenAI SDK and fully configure server-side execution pathways.
*   **Web Ingress UI**: Code and polish the user-facing web applications.
*   **Budget Ceiling Compliance**: Strictly maintain budget allocations within the **$45,000 USD** threshold.

### 3. Resource & Team Routing
*   **Dave**: Provisioning secure Google Cloud / Firebase server environments.
*   **John**: Building the custom Express/Vite proxy API backend.
*   **Sarah**: Conducting complete end-to-end integration and load testing.`,
    executive: `### BLUF (Bottom Line Up Front)
DeliverAI Pro is scheduled for an early Q3 launch with a maximum budget cap of **$45,000**. Critical dependencies are engineering completions by **June 28** and marketing initialization by **July 5**.

### Key Actions
*   **GenAI Integration**: John finalizing backend logic under strict timelines.
*   **Cloud Operations**: Dave preparing database and firewall environments.
*   **Quality Assurance**: Sarah executing user walkthrough testing.`,
    academic: `## Contextual Analysis: Rapid Prototyping & Generative Systems
This study reviews the technical mechanics deployed to scale the DeliverAI Pro generative middleware ecosystem. It details the utilization of the @google/genai module for parsing raw input, extracting key intents, and executing tone adjustments.

### Key Concepts Definitions
*   **Generative Middleware**: Intermediate server instances designed to buffer and scrub telemetry before making queries to Large Language Models.
*   **Multi-Modal Injection**: The capacity of neural networks to simultaneously process audio files and unstructured strings to form an integrated vector.`,
    qualityScores: {
      readability: 92,
      professionalism: 96,
      completeness: 88,
      clarity: 90
    },
    productivityInsights: {
      estimatedTimeSavedMinutes: 120,
      tasksIdentified: [
        "Finalize main landing page layouts",
        "Integrate official Google GenAI SDK on server endpoints",
        "Initialize marketing ad campaigns"
      ],
      deadlinesFound: [
        "June 28: Complete development and integration",
        "July 5: Initiate ad campaigns"
      ],
      decisionsExtracted: [
        "Launch target set for early Q3",
        "Approve budget ceiling at $45,000 USD",
        "Agree to use standard Express, Vite, and node for scaling"
      ]
    },
    summary: "DeliverAI Pro Q3 product launching sync overview defining milestones, budget caps, and marketing ad scheduling."
  },
  {
    id: "seed-2",
    inputText: "Marketing brainstorm: Create a friendly, corporate announcement email introducing the new automated HR benefit cards. We are rolling out GymPass and Headspace free for all employees. It goes live on August 1st. Please click the link to register before July 15th so we can forecast cost.",
    deliverableType: "email",
    tone: "friendly",
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 days ago
    professional: `Subject: Introducing Your New Wellness Benefits: Free GymPass & Headspace!

Dear Team,

We are absolutely thrilled to share a new addition to our employee care program designed to support your physical and emotional well-being!

Starting **August 1st**, all full-time employees will gain complimentary, full access to **GymPass** and the **Headspace** meditation platform. 

### What is Included?
1.  **GymPass**: Premium access to a global network of thousands of yoga classes, fitness studios, weight gyms, and sports clubs.
2.  **Headspace Premium**: Complete unlock of the guided sleep aids, stress management modules, and focusing audio streams.

### Required Employee Action
To ensure our financial forecasting is optimized for licensing, we kindly ask everyone to submit their enrollment registrations no later than **Friday, July 15th**.

Please click here to confirm your wellness card activation.

In wellness,  
Your People Operations Team`,
    executive: `Subject: HR Benefit Rollout: Access Free GymPass & Headspace starting August 1st

### BLUF
Complimentary corporate wellness licenses for GymPass and Headspace go live on **August 1st**. Actions required before **July 15th**.

### Actions Needed
1. Review the HR Portal registration page.
2. Complete signup by **July 15** to secure your account licenses.`,
    academic: `## Analytical Review: Cognitive Restructuring & Health Incentives
This study note evaluates the impacts of systematic corporate wellness incentives on overall occupational health metrics, exploring how platforms like GymPass and mindfulness suites like Headspace impact corporate productivity.

### Theoretical Pillars
*   **Preventative Biomechanics**: Enhancing physical resilience lowers workplace injury rates and boosts workplace satisfaction.
*   **Mindfulness Intervention**: Short, systematic meditation loops have been proven empirically to decrease anxiety metrics.`,
    qualityScores: {
      readability: 98,
      professionalism: 92,
      completeness: 95,
      clarity: 97
    },
    productivityInsights: {
      estimatedTimeSavedMinutes: 45,
      tasksIdentified: [
        "Register for enrollment in GymPass and Headspace programs",
        "Forecast employee wellness card licensing expenditures"
      ],
      deadlinesFound: [
        "July 15: Registration deadline for employees",
        "August 1: Live kickoff of wellness benefits"
      ],
      decisionsExtracted: [
        "Roll out free GymPass and Headspace licenses",
        "Finance wellness licenses directly from corporate People Operations budget"
      ]
    },
    summary: "HR team announcement outlining GymPass and Headspace benefits, enrollment deadlines, and registration URLs."
  }
];

export function getStoredDeliverables(): Deliverable[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(SEED_DELIVERABLES));
      return SEED_DELIVERABLES;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error("Error reading deliverables from storage:", err);
    return SEED_DELIVERABLES;
  }
}

export function saveStoredDeliverables(list: Deliverable[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(list));
  } catch (err) {
    console.error("Error writing deliverables to storage:", err);
  }
}

export function addStoredDeliverable(item: Deliverable): Deliverable[] {
  const current = getStoredDeliverables();
  const updated = [item, ...current];
  saveStoredDeliverables(updated);
  return updated;
}

export function deleteStoredDeliverable(id: string): Deliverable[] {
  const current = getStoredDeliverables();
  const updated = current.filter((x) => x.id !== id);
  saveStoredDeliverables(updated);
  return updated;
}
