import { jsPDF } from "jspdf";
import { Deliverable } from "../types";

export interface PdfBlock {
  type: "text" | "heading1" | "heading2" | "heading3" | "list" | "math" | "chart" | "flow" | "concept" | "revision" | "important";
  title?: string;
  meta?: string;
  lines: string[];
}

export function parsePdfBlocks(text: string): PdfBlock[] {
  const rawLines = text.split("\n");
  const blocks: PdfBlock[] = [];
  
  let currentBlock: PdfBlock | null = null;
  
  for (let line of rawLines) {
    const trimmed = line.trim();
    if (!trimmed && !currentBlock) continue;
    
    // Check block starts
    if (trimmed.startsWith("[MATH_START]")) {
      if (currentBlock) blocks.push(currentBlock);
      currentBlock = { type: "math", lines: [] };
    } else if (trimmed === "[MATH_END]") {
      if (currentBlock) {
        blocks.push(currentBlock);
        currentBlock = null;
      }
    } else if (trimmed.startsWith("[CHART_START:")) {
      if (currentBlock) blocks.push(currentBlock);
      const match = trimmed.match(/^\[CHART_START:(bar|line|pie):(.*?)\]$/i);
      currentBlock = { 
        type: "chart", 
        meta: match ? match[1].toLowerCase() : "bar", 
        title: match ? match[2] : "Data Visualization", 
        lines: [] 
      };
    } else if (trimmed === "[CHART_END]") {
      if (currentBlock) {
        blocks.push(currentBlock);
        currentBlock = null;
      }
    } else if (trimmed.startsWith("[FLOW_START:")) {
      if (currentBlock) blocks.push(currentBlock);
      const match = trimmed.match(/^\[FLOW_START:(.*?)\]$/);
      currentBlock = { 
        type: "flow", 
        title: match ? match[1] : "Timeline Lifecycle", 
        lines: [] 
      };
    } else if (trimmed === "[FLOW_END]") {
      if (currentBlock) {
        blocks.push(currentBlock);
        currentBlock = null;
      }
    } else if (trimmed.startsWith("[CONCEPT_START:")) {
      if (currentBlock) blocks.push(currentBlock);
      const match = trimmed.match(/^\[CONCEPT_START:(.*?)\]$/);
      currentBlock = { 
        type: "concept", 
        title: match ? match[1] : "Concept Summary Maps", 
        lines: [] 
      };
    } else if (trimmed === "[CONCEPT_END]") {
      if (currentBlock) {
        blocks.push(currentBlock);
        currentBlock = null;
      }
    } else if (trimmed.startsWith("[REVISION_START:") || trimmed.startsWith("[REVISION_START]")) {
      if (currentBlock) blocks.push(currentBlock);
      const match = trimmed.match(/^\[REVISION_START:(.*?)\]$/);
      currentBlock = { 
        type: "revision", 
        title: match ? match[1] : "Quick Revision Checklist", 
        lines: [] 
      };
    } else if (trimmed === "[REVISION_END]") {
      if (currentBlock) {
        blocks.push(currentBlock);
        currentBlock = null;
      }
    } else if (trimmed.startsWith("[IMPORTANT_START:") || trimmed.startsWith("[IMPORTANT_START]")) {
      if (currentBlock) blocks.push(currentBlock);
      const match = trimmed.match(/^\[IMPORTANT_START:(.*?)\]$/);
      currentBlock = { 
        type: "important", 
        title: match ? match[1] : "High-Yield Notes Card", 
        lines: [] 
      };
    } else if (trimmed === "[IMPORTANT_END]" || trimmed === "[IMPORTANT_END]") {
      if (currentBlock) {
        blocks.push(currentBlock);
        currentBlock = null;
      }
    } else {
      // In-block collector
      if (currentBlock) {
        currentBlock.lines.push(line);
      } else {
        // Outside of standard block
        if (line.startsWith("# ")) {
          blocks.push({ type: "heading1", lines: [line.replace("# ", "")] });
        } else if (line.startsWith("## ")) {
          blocks.push({ type: "heading2", lines: [line.replace("## ", "")] });
        } else if (line.startsWith("### ")) {
          blocks.push({ type: "heading3", lines: [line.replace("### ", "")] });
        } else if (line.startsWith("- ") || line.startsWith("* ")) {
          blocks.push({ type: "list", lines: [line.substring(2)] });
        } else {
          blocks.push({ type: "text", lines: [line] });
        }
      }
    }
  }
  
  if (currentBlock) blocks.push(currentBlock);
  return blocks;
}

export function generateStyledPDF(deliverable: Deliverable, text: string, title: string) {
  const doc = new jsPDF("p", "mm", "a4");
  const pageWidth = doc.internal.pageSize.getWidth(); // A4 is 210
  const pageHeight = doc.internal.pageSize.getHeight(); // A4 is 297
  const margin = 18;
  const maxLineWidth = pageWidth - (margin * 2); // 174
  
  let currentY = 22;
  const blocks = parsePdfBlocks(text);

  const drawHeaderDecoration = () => {
    // Upper accent bar (Deep slate blue theme)
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(margin, currentY, maxLineWidth, 30, "F");
    
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(14);
    doc.setTextColor(255, 255, 255);
    doc.text("DELIVERAI PRO • PREMIUM STUDY RESOURCES", margin + 8, currentY + 11);
    
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(186, 230, 253); // sky-250 cyan accent
    
    const label = deliverable.deliverableType.replace("_", " ").toUpperCase();
    const formattedDate = new Date(deliverable.createdAt).toLocaleDateString(undefined, {
      month: "short", day: "numeric", year: "numeric"
    });
    
    doc.text(`DELIVERABLE: ${label} | TONE: ${title.toUpperCase()} | DATE: ${formattedDate}`, margin + 8, currentY + 20);
    currentY += 40;
  };

  const drawPageBorderDecoration = (pageNum: number, totalPages: number) => {
    doc.setPage(pageNum);
    
    // Page outline/header bar line decoration
    doc.setDrawColor(241, 245, 249); // slate-100 line
    doc.setLineWidth(0.4);
    doc.line(margin, 12, pageWidth - margin, 12);
    
    // Header label
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text(`DeliverAI Pro Premium Companion: ${deliverable.deliverableType.replace("_", " ").toUpperCase()}`, margin, 9);
    
    // Bottom line
    doc.line(margin, pageHeight - 14, pageWidth - margin, pageHeight - 14);
    
    // Footer stamps
    doc.text(`Generated securely via Workspace AI • Study Notes Suite`, margin, pageHeight - 9);
    doc.text(`Page ${pageNum} of ${totalPages}`, pageWidth - margin - 15, pageHeight - 9);
  };

  const checkPageOverflow = (heightNeeded: number) => {
    if (currentY + heightNeeded > pageHeight - 22) {
      doc.addPage();
      currentY = 22;
      return true;
    }
    return false;
  };

  // Initial Header Draw
  drawHeaderDecoration();

  // Run over parsed blocks rendering visual custom interfaces inside PDF
  for (const block of blocks) {
    if (block.lines.filter(l => l.trim()).length === 0 && block.type !== "text") continue;

    switch (block.type) {
      case "heading1": {
        const val = block.lines[0];
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(16);
        doc.setTextColor(15, 23, 42); // deep slate
        
        const lines = doc.splitTextToSize(val, maxLineWidth);
        checkPageOverflow(lines.length * 7 + 10);
        
        currentY += 4;
        // Draw a colored under-bar for Heading 1
        doc.setFillColor(79, 70, 229); // Indigo line
        doc.rect(margin, currentY, 8, 2, "F");
        currentY += 5;
        
        lines.forEach((l: string) => {
          doc.text(l, margin, currentY);
          currentY += 7;
        });
        currentY += 2;
        break;
      }
      
      case "heading2": {
        const val = block.lines[0];
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(12.5);
        doc.setTextColor(67, 56, 202); // indigo-700
        
        const lines = doc.splitTextToSize(val, maxLineWidth);
        checkPageOverflow(lines.length * 6 + 7);
        
        currentY += 4;
        lines.forEach((l: string) => {
          doc.text(l, margin, currentY);
          currentY += 6;
        });
        currentY += 2;
        break;
      }
      
      case "heading3": {
        const val = block.lines[0];
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(13, 148, 136); // teal-600
        
        const lines = doc.splitTextToSize(val, maxLineWidth);
        checkPageOverflow(lines.length * 5.5 + 5);
        
        currentY += 3;
        lines.forEach((l: string) => {
          doc.text(l, margin, currentY);
          currentY += 5.5;
        });
        currentY += 1.5;
        break;
      }

      case "list": {
        const val = block.lines[0];
        doc.setFont("Helvetica", "normal");
        doc.setFontSize(10);
        doc.setTextColor(64, 74, 86); // softer grey
        
        // Remove bold markdown tags
        const cleanList = val.replace(/\*\*(.*?)\*\*/g, "$1");
        const lines = doc.splitTextToSize(cleanList, maxLineWidth - 6);
        checkPageOverflow(lines.length * 5.5 + 2);
        
        // Draw bullet point dot
        doc.setFillColor(79, 70, 229);
        doc.circle(margin + 2, currentY - 1.2, 1.1, "F");
        
        lines.forEach((l: string) => {
          doc.text(l, margin + 6, currentY);
          currentY += 5.5;
        });
        currentY += 1;
        break;
      }

      case "math": {
        const equations = block.lines.map(l => l.trim()).filter(Boolean);
        if (equations.length === 0) break;
        
        const blockHeight = 12 + (equations.length * 7);
        checkPageOverflow(blockHeight + 8);
        
        currentY += 2;
        // Container background
        doc.setFillColor(248, 250, 252); // light slate background
        doc.rect(margin, currentY, maxLineWidth, blockHeight, "F");
        
        // Left brand border tag
        doc.setFillColor(79, 70, 229); // Purple marker
        doc.rect(margin, currentY, 3, blockHeight, "F");
        
        // Title
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(8.5);
        doc.setTextColor(79, 70, 229);
        doc.text("KEY MATHEMATICAL FORMULA / EQUATION", margin + 7, currentY + 5);
        
        // Render each equation inside the shaded block
        doc.setFont("Times", "italic");
        doc.setFontSize(11);
        doc.setTextColor(30, 41, 59);
        
        let eqnY = currentY + 12;
        equations.forEach((eq) => {
          // Translate latex terms for clean printable text
          const readable = eq
            .replace(/\\bar\{x\}/g, "x-bar")
            .replace(/\\tau/g, "τ")
            .replace(/\\sigma/g, "σ")
            .replace(/\\pi/g, "π")
            .replace(/\\mu/g, "μ")
            .replace(/\\Sigma/g, "Σ")
            .replace(/\\epsilon/g, "ε")
            .replace(/\\int_\{(.*?)\}\^\{(.*?)\}/g, "∫($1 to $2)")
            .replace(/\\int/g, "∫")
            .replace(/\\sum_\{(.*?)\}\^\{(.*?)\}/g, "Σ($1 to $2)")
            .replace(/\\sum/g, "Σ")
            .replace(/\\frac\{(.*?)\}\{(.*?)\}/g, "($1 / $2)")
            .replace(/\\sqrt\{(.*?)\}/g, "√($1)")
            .replace(/\^\{(.*?)\}/g, "^$1")
            .replace(/_\{(.*?)\}/g, "_$1");

          doc.text(readable, margin + 10, eqnY);
          eqnY += 7;
        });
        
        currentY += blockHeight + 4;
        break;
      }

      case "chart": {
        // Parse numerical list inside the PDF
        const rawLines = block.lines;
        const data: { name: string; value: number }[] = [];
        let maxVal = 1;
        
        for (const l of rawLines) {
          const trimmed = l.trim();
          if (!trimmed) continue;
          const colonIdx = trimmed.indexOf(":");
          if (colonIdx !== -1) {
            const rawName = trimmed.substring(0, colonIdx).trim().replace(/^\*\s*|\*\s*$/g, "");
            const rawVal = trimmed.substring(colonIdx + 1).trim();
            const valNum = parseFloat(rawVal);
            if (!isNaN(valNum)) {
              data.push({ name: rawName, value: valNum });
              if (valNum > maxVal) maxVal = valNum;
            }
          }
        }
        
        if (data.length === 0) break;
        
        const chartType = block.meta || "bar";
        const chartTitle = block.title || "Numerical Table Insight";
        const blockHeight = 22 + (data.length * 8.5);
        
        checkPageOverflow(blockHeight + 10);
        
        currentY += 2;
        // Background container bordered
        doc.setFillColor(248, 250, 252);
        doc.rect(margin, currentY, maxLineWidth, blockHeight, "F");
        
        doc.setLineWidth(0.25);
        doc.setDrawColor(218, 223, 230);
        doc.rect(margin, currentY, maxLineWidth, blockHeight, "D");
        
        // Header line
        doc.setFillColor(30, 41, 59);
        doc.rect(margin, currentY, maxLineWidth, 8.5, "F");
        
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(255, 255, 255);
        const iconLabel = chartType === "pie" ? "🟢 Pie representation table: " : chartType === "line" ? "📈 Growth Table: " : "📊 Comparison Table: ";
        doc.text(`${iconLabel}${chartTitle.toUpperCase()}`, margin + 5, currentY + 5.5);
        
        let rowY = currentY + 15;
        data.forEach((row, rIdx) => {
          doc.setFont("Helvetica", "bold");
          doc.setFontSize(8.5);
          doc.setTextColor(51, 65, 85);
          doc.text(row.name, margin + 5, rowY);
          
          doc.setFont("Helvetica", "normal");
          doc.text(row.value.toLocaleString(), margin + 90, rowY);
          
          // Draw neat proportional visual bar indicator
          const barWidth = Math.max(2, Math.min(65, (row.value / maxVal) * 65));
          doc.setFillColor(79, 70, 229); // indigo
          doc.rect(margin + 105, rowY - 2.8, barWidth, 3.5, "F");
          
          // Row base separator line
          if (rIdx < data.length - 1) {
            doc.setDrawColor(235, 240, 245);
            doc.line(margin + 2, rowY + 3, margin + maxLineWidth - 2, rowY + 3);
          }
          
          rowY += 8.5;
        });
        
        currentY += blockHeight + 5;
        break;
      }

      case "flow": {
        // Sequential Flow timeline
        const rawLines = block.lines;
        const steps: { label: string; desc: string }[] = [];
        
        for (const line of rawLines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          
          let clean = trimmed;
          const colonIdx = trimmed.indexOf(":");
          if (colonIdx !== -1 && trimmed.toLowerCase().startsWith("step")) {
            clean = trimmed.substring(colonIdx + 1).trim();
          }
          
          const pipeIdx = clean.indexOf("|");
          if (pipeIdx !== -1) {
            steps.push({
              label: clean.substring(0, pipeIdx).trim(),
              desc: clean.substring(pipeIdx + 1).trim()
            });
          } else {
            steps.push({ label: clean, desc: "" });
          }
        }
        
        if (steps.length === 0) break;
        
        // Compute block height
        let blockHeight = 15;
        steps.forEach((st) => {
          const descLines = doc.splitTextToSize(st.desc, maxLineWidth - 18);
          blockHeight += 10 + (st.desc ? descLines.length * 5 : 0);
        });
        
        checkPageOverflow(blockHeight + 10);
        
        currentY += 2;
        // Flow card contour
        doc.setFillColor(250, 251, 252);
        doc.setDrawColor(224, 231, 255); // indigo-100 outline
        doc.rect(margin, currentY, maxLineWidth, blockHeight, "FD");
        
        // Header
        doc.setFillColor(79, 70, 229);
        doc.rect(margin, currentY, maxLineWidth, 8.5, "F");
        
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(255, 255, 255);
        doc.text(`🔗 SEQUENTIAL FLOW: ${block.title?.toUpperCase() || "PROCESS STAGES"}`, margin + 6, currentY + 5.5);
        
        let stepY = currentY + 16;
        steps.forEach((st, idx) => {
          // Number indicator
          doc.setFillColor(30, 41, 59);
          doc.rect(margin + 5, stepY - 3, 6, 4.5, "F");
          doc.setFont("Helvetica", "bold");
          doc.setFontSize(7.5);
          doc.setTextColor(255, 255, 255);
          doc.text(`${idx + 1}`, margin + 7.5, stepY + 0.3);
          
          // Header of the node stage
          doc.setFontSize(9);
          doc.setTextColor(30, 41, 59);
          doc.text(st.label, margin + 14, stepY);
          
          stepY += 4;
          
          // Step Description text
          if (st.desc) {
            doc.setFont("Helvetica", "normal");
            doc.setFontSize(8.5);
            doc.setTextColor(71, 85, 105);
            
            const descLines = doc.splitTextToSize(st.desc, maxLineWidth - 20);
            descLines.forEach((l: string) => {
              doc.text(l, margin + 14, stepY + 0.5);
              stepY += 5;
            });
          }
          
          // Draw intermediate connecting timeline line
          if (idx < steps.length - 1) {
            doc.setDrawColor(199, 210, 254);
            doc.line(margin + 8, stepY - 2, margin + 8, stepY + 1);
            stepY += 2;
          }
        });
        
        currentY += blockHeight + 5;
        break;
      }

      case "concept": {
        // Concept Bento Grid blocks
        const rawLines = block.lines;
        const concepts: { badge: string; title: string; desc: string }[] = [];
        
        for (const l of rawLines) {
          const trimmed = l.trim();
          if (!trimmed) continue;
          const parts = trimmed.split("|");
          if (parts.length >= 3) {
            concepts.push({
              badge: parts[0].trim(),
              title: parts[1].trim(),
              desc: parts.slice(2).join("|").trim()
            });
          } else if (parts.length === 2) {
            concepts.push({
              badge: "Insight",
              title: parts[0].trim(),
              desc: parts[1].trim()
            });
          }
        }
        
        if (concepts.length === 0) break;
        
        let blockHeight = 15;
        concepts.forEach((c) => {
          const lines = doc.splitTextToSize(c.desc, maxLineWidth - 16);
          blockHeight += 12 + lines.length * 5;
        });
        
        checkPageOverflow(blockHeight + 10);
        
        currentY += 2;
        doc.setFillColor(255, 255, 255);
        doc.setDrawColor(233, 213, 255); // rich purple frame
        doc.rect(margin, currentY, maxLineWidth, blockHeight, "FD");
        
        doc.setFillColor(147, 51, 234); // solid purple header
        doc.rect(margin, currentY, maxLineWidth, 8.5, "F");
        
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(255, 255, 255);
        doc.text(`🧠 CONCEPT SUMMARY MAP: ${block.title?.toUpperCase() || "CORE TOPICS"}`, margin + 6, currentY + 5.5);
        
        let conceptY = currentY + 16;
        concepts.forEach((comp) => {
          // Purple Badge Draw
          doc.setFillColor(243, 232, 255);
          doc.rect(margin + 6, conceptY - 3.2, 16, 4.5, "F");
          
          doc.setFont("Helvetica", "bold");
          doc.setFontSize(7.5);
          doc.setTextColor(147, 51, 234);
          doc.text(comp.badge.substring(0, 10).toUpperCase(), margin + 8, conceptY + 0.1);
          
          // Concept Title
          doc.setFontSize(9);
          doc.setTextColor(15, 23, 42);
          doc.text(comp.title, margin + 25, conceptY);
          conceptY += 4.5;
          
          // Concept Body Detail
          doc.setFont("Helvetica", "normal");
          doc.setFontSize(8.5);
          doc.setTextColor(71, 85, 105);
          
          const lines = doc.splitTextToSize(comp.desc, maxLineWidth - 14);
          lines.forEach((l: string) => {
            doc.text(l, margin + 7, conceptY);
            conceptY += 5;
          });
          
          conceptY += 1.5;
        });
        
        currentY += blockHeight + 5;
        break;
      }

      case "revision": {
        // Quick revision indices
        const rawLines = block.lines.filter(l => l.trim());
        if (rawLines.length === 0) break;
        
        const blockHeight = 12 + (rawLines.length * 6);
        checkPageOverflow(blockHeight + 10);
        
        currentY += 2;
        doc.setFillColor(244, 252, 245); // soft emerald revision green
        doc.setDrawColor(187, 247, 208);
        doc.rect(margin, currentY, maxLineWidth, blockHeight, "FD");
        
        doc.setFillColor(22, 163, 74); // green header
        doc.rect(margin, currentY, maxLineWidth, 8.5, "F");
        
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(255, 255, 255);
        doc.text(`⚡ QUICK REVISION RECAP: ${block.title?.toUpperCase() || "CHECKLIST BOARD"}`, margin + 6, currentY + 5.5);
        
        doc.setFont("Helvetica", "normal");
        doc.setFontSize(8.5);
        doc.setTextColor(30, 41, 59);
        
        let bulletY = currentY + 15;
        rawLines.forEach((l) => {
          const cleanLine = l.replace(/^\*\s*|-\s*/, "").replace(/\*\*(.*?)\*\*/g, "$1");
          const lines = doc.splitTextToSize(cleanLine, maxLineWidth - 14);
          
          doc.setFillColor(22, 163, 74);
          doc.circle(margin + 6, bulletY - 1, 0.9, "F");
          
          lines.forEach((p: string) => {
            doc.text(p, margin + 11, bulletY);
            bulletY += 5.5;
          });
          bulletY += 0.5;
        });
        
        currentY += blockHeight + 5;
        break;
      }

      case "important": {
        // High-Yield Important Takeaways card
        const rawLines = block.lines.filter(l => l.trim());
        if (rawLines.length === 0) break;
        
        const blockHeight = 14 + (rawLines.length * 6);
        checkPageOverflow(blockHeight + 10);
        
        currentY += 2;
        doc.setFillColor(254, 243, 199); // Soft amber warning card
        doc.setDrawColor(251, 191, 36);
        doc.rect(margin, currentY, maxLineWidth, blockHeight, "FD");
        
        doc.setFillColor(217, 119, 6);
        doc.rect(margin, currentY, 3, blockHeight, "F"); // Left thick stripe
        
        doc.setFont("Helvetica", "bold");
        doc.setFontSize(9.5);
        doc.setTextColor(146, 64, 14); // Dark amber title
        doc.text(`🔥 IMPORTANT STUDY BRIEF: ${block.title?.toUpperCase() || "CRITICAL POINT"}`, margin + 8, currentY + 6);
        
        doc.setFont("Helvetica", "normal");
        doc.setFontSize(8.5);
        doc.setTextColor(120, 53, 4);
        
        let importantY = currentY + 12;
        rawLines.forEach((l) => {
          const cleanLine = l.replace(/^\*\s*|-\s*/, "").replace(/\*\*(.*?)\*\*/g, "$1");
          const lines = doc.splitTextToSize(cleanLine, maxLineWidth - 14);
          
          lines.forEach((p: string) => {
            doc.text(p, margin + 9, importantY);
            importantY += 5.5;
          });
          importantY += 0.5;
        });
        
        currentY += blockHeight + 5;
        break;
      }

      case "text":
      default: {
        const fullPara = block.lines.join("\n").trim();
        if (!fullPara) break;
        
        doc.setFont("Helvetica", "normal");
        doc.setFontSize(10);
        doc.setTextColor(51, 65, 85); // elegant slate grey
        
        const cleanPara = fullPara.replace(/\*\*(.*?)\*\*/g, "$1");
        const lines = doc.splitTextToSize(cleanPara, maxLineWidth);
        
        const blockHeight = lines.length * 5.6;
        checkPageOverflow(blockHeight + 3);
        
        lines.forEach((l: string) => {
          doc.text(l, margin, currentY);
          currentY += 5.6;
        });
        currentY += 2;
        break;
      }
    }
  }

  // Draw full borders, page headers and footers on any active pages compiled
  const totalPages = doc.internal.pages.length - 1;
  for (let p = 1; p <= totalPages; p++) {
    drawPageBorderDecoration(p, totalPages);
  }

  const cleanTitle = `${deliverable.deliverableType.toUpperCase()}_${title.toUpperCase()}_COMPANION`;
  doc.save(`${cleanTitle}.pdf`);
}
