import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Configuration from firebase-applet-config.json
const firebaseConfig = {
  apiKey: "AIzaSyBbYzNrKWZZwks2hHq8-j1JNd7Xc1JdyNE",
  authDomain: "vast-totality-hf4nj.firebaseapp.com",
  projectId: "vast-totality-hf4nj",
  storageBucket: "vast-totality-hf4nj.firebasestorage.app",
  messagingSenderId: "937599913246",
  appId: "1:937599913246:web:66993c442183fed4170d0f"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app, "ai-studio-7dc5c6cf-0a5e-4b29-8c89-5ed3f4fb2e69");
