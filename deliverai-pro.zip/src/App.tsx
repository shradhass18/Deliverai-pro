import { useState, useEffect } from "react";
import { 
  getStoredDeliverables, 
  addStoredDeliverable, 
  deleteStoredDeliverable 
} from "./utils/db";
import { auth, db } from "./lib/firebase";
import { onAuthStateChanged, signOut, updateProfile } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { 
  fetchDeliverablesFromFirestore,
  saveDeliverableToFirestore,
  deleteDeliverableFromFirestore,
  seedUserIfEmpty
} from "./utils/firebaseDb";
import AuthScreen from "./components/AuthScreen";
import { Deliverable, ActiveTab, UserProfile } from "./types";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import DashboardPanel from "./components/DashboardPanel";
import InputWorkspace from "./components/InputWorkspace";
import ComparisonWorkspace from "./components/ComparisonWorkspace";
import HistoryPanel from "./components/HistoryPanel";
import AnalyticsPanel from "./components/AnalyticsPanel";
import SettingsPanel from "./components/SettingsPanel";
import { ShieldX, AlertTriangle, X, Loader2, Sparkles } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("dashboard");
  const [searchQuery, setSearchQuery] = useState("");
  const [deliverables, setDeliverables] = useState<Deliverable[]>([]);
  const [selectedDeliverable, setSelectedDeliverable] = useState<Deliverable | null>(null);
  const [particles, setParticles] = useState<Array<{ id: number; left: string; delay: string; duration: string; size: string; opacity: number }>>([]);

  useEffect(() => {
    // Generate organic cosmic drifting particle dust
    const dust = Array.from({ length: 24 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * -20}s`, // start immediately at randomized timings
      duration: `${Math.random() * 25 + 25}s`,
      size: `${Math.random() * 3 + 1.5}px`,
      opacity: Math.random() * 0.45 + 0.15
    }));
    setParticles(dust);
  }, []);

  // Auth User Tracking
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);

  // Profile settings state synced with Auth / localStorage fallback
  const [profile, setProfile] = useState<UserProfile>({
    name: "Shradha CSG",
    email: "shradhacsg05@gmail.com",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"
  });

  // State to manage simulated steps
  const [isGenerating, setIsGenerating] = useState(false);
  const [isRewriting, setIsRewriting] = useState(false);
  const [activeGenerationStep, setActiveGenerationStep] = useState<string>("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Firebase cloud status
  const [firebaseStatus, setFirebaseStatus] = useState({
    active: true,
    termsAccepted: true
  });

  // Firebase auth status subscription
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        const dispName = user.displayName || "Shradha CSG";
        const emailAddr = user.email || "shradhacsg05@gmail.com";
        const avatarLink = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(dispName)}`;
        
        setProfile({
          name: dispName,
          email: emailAddr,
          avatarUrl: avatarLink
        });

        // Load or seed user deliverables from Firestore
        setIsGenerating(true);
        try {
          const list = await seedUserIfEmpty(user.uid);
          setDeliverables(list);
        } catch (err: any) {
          console.error("Failed to seed or get deliverables:", err);
          setErrorMessage("Failed to load cloud deliverables. Offline cache will be used instead.");
          setDeliverables(getStoredDeliverables());
        } finally {
          setIsGenerating(false);
        }
      } else {
        setCurrentUser(null);
        setDeliverables([]);
      }
      setIsLoadingUser(false);
    });
    return () => unsubscribe();
  }, []);

  const handleUpdateProfile = async (newProfile: UserProfile) => {
    setProfile(newProfile);
    localStorage.setItem("deliverai_pro_profile_v1", JSON.stringify(newProfile));
    
    if (auth.currentUser) {
      try {
        await updateProfile(auth.currentUser, {
          displayName: newProfile.name
        });
        
        // Sync user document details in firestore
        const udoc = doc(db, "users", auth.currentUser.uid);
        await setDoc(udoc, {
          uid: auth.currentUser.uid,
          name: newProfile.name,
          email: newProfile.email,
          updatedAt: new Date().toISOString()
        }, { merge: true });
        
      } catch (err: any) {
        console.error("Profile sync fail:", err);
      }
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setCurrentUser(null);
    setProfile({
      name: "",
      email: "",
      avatarUrl: ""
    });
    setDeliverables([]);
    setSelectedDeliverable(null);
  };

  const handleDeleteDeliverable = async (id: string) => {
    if (currentUser) {
      try {
        await deleteDeliverableFromFirestore(id);
        const updated = await fetchDeliverablesFromFirestore(currentUser.uid);
        setDeliverables(updated);
      } catch (err: any) {
        console.error("Firestore delete fail:", err);
      }
    } else {
      const updated = deleteStoredDeliverable(id);
      setDeliverables(updated);
    }
    
    if (selectedDeliverable?.id === id) {
      setSelectedDeliverable(null);
    }
  };

  // Main Core AI Generate execution pathway
  const handleGenerate = async (
    inputText: string, 
    deliverableType: string, 
    tone: string, 
    file: any
  ) => {
    setIsGenerating(true);
    setErrorMessage(null);

    try {
      // Step 1: Input Analysis Agent
      setActiveGenerationStep("analyze");
      await new Promise((r) => setTimeout(r, 1000));

      // Step 2: Information Extraction Agent
      setActiveGenerationStep("extract");
      await new Promise((r) => setTimeout(r, 1000));

      // Step 3: Deliverable Planning Agent
      setActiveGenerationStep("plan");
      await new Promise((r) => setTimeout(r, 800));

      // Step 4: Content Generation Agent
      setActiveGenerationStep("generate");
      
      const payload = {
        inputText,
        deliverableType,
        tone,
        userProfile: profile,
        file: file ? { name: file.name, type: file.type, size: file.size, data: file.data } : null
      };

      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || "Failed to generate deliverable from Gemini. Please make sure GEMINI_API_KEY is configured.");
      }

      const data = await response.json();

      // Step 5: Quality Review Agent
      setActiveGenerationStep("review");
      await new Promise((r) => setTimeout(r, 1000));

      // Step 6: Export Agent (Finalization & Sync)
      setActiveGenerationStep("export");
      await new Promise((r) => setTimeout(r, 800));

      // Construct a new fully formed Deliverable record
      const newDeliverable: Deliverable = {
        id: `del-${Date.now()}`,
        inputText: inputText || `Synthesized analysis from attached document: ${file?.name || "unnamed"}`,
        deliverableType: deliverableType as any,
        tone: tone as any,
        file: file ? { name: file.name, type: file.type, size: file.size, data: file.data } : undefined,
        professional: data.professional,
        executive: data.executive,
        academic: data.academic,
        qualityScores: data.qualityScores,
        productivityInsights: data.productivityInsights,
        summary: data.summary,
        createdAt: new Date().toISOString()
      };

      // Push to history database
      if (currentUser) {
        await saveDeliverableToFirestore(currentUser.uid, newDeliverable);
        const updatedList = await fetchDeliverablesFromFirestore(currentUser.uid);
        setDeliverables(updatedList);
      } else {
        const updatedList = addStoredDeliverable(newDeliverable);
        setDeliverables(updatedList);
      }
      
      // Auto open newly completed deliverable inside the comparison deck!
      setSelectedDeliverable(newDeliverable);
    } catch (err: any) {
      console.error("AI Generation error:", err);
      setErrorMessage(err.message || "An unexpected error occurred while communicating with Gemini API routing. Double check settings.");
    } finally {
      setIsGenerating(false);
      setActiveGenerationStep("idle");
    }
  };

  // Re-write tools modifier logic
  const handleRewriteModifier = async (modifier: string) => {
    if (!selectedDeliverable) return;
    setIsRewriting(true);
    setErrorMessage(null);

    try {
      const payload = {
        inputText: selectedDeliverable.inputText,
        deliverableType: selectedDeliverable.deliverableType,
        tone: modifier, // Injecting modified action instructions as tone to direct Gemini specifically
        userProfile: profile,
        file: selectedDeliverable.file || null
      };

      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || "Failed to execute AI rewrite.");
      }

      const data = await response.json();

      // Update the current active item with refined contents
      const refinedDeliverable: Deliverable = {
        ...selectedDeliverable,
        professional: data.professional,
        executive: data.executive,
        academic: data.academic,
        qualityScores: data.qualityScores,
        productivityInsights: data.productivityInsights,
        summary: data.summary,
        createdAt: new Date().toISOString() // update timestamp
      };

      // Replace old ID record in list
      if (currentUser) {
        await saveDeliverableToFirestore(currentUser.uid, refinedDeliverable);
        const updatedList = await fetchDeliverablesFromFirestore(currentUser.uid);
        setDeliverables(updatedList);
      } else {
        const currentList = getStoredDeliverables();
        const replacedList = currentList.map((item) => item.id === selectedDeliverable.id ? refinedDeliverable : item);
        setDeliverables(replacedList);
        localStorage.setItem("deliverai_pro_deliverables_v1", JSON.stringify(replacedList));
      }

      setSelectedDeliverable(refinedDeliverable);
    } catch (err: any) {
      console.error("Rewrite error:", err);
      setErrorMessage(err.message || "Failed to process AI rewrite refinement request.");
    } finally {
      setIsRewriting(false);
    }
  };

  const triggerFirebaseProposal = () => {
    setErrorMessage("Cloud Provisioning Proposal: To set up a persistent Firebase Firestore Database, click the Cloud Setup tools configurations.");
  };

  if (isLoadingUser) {
    return (
      <div className="min-h-screen w-full flex flex-col justify-center items-center bg-[#020617]">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-cyan-500/5 blur-[120px] pointer-events-none"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[30rem] h-[30rem] rounded-full bg-indigo-500/5 blur-[140px] pointer-events-none"></div>
        <div className="text-center space-y-4 relative z-10 animate-fade-in">
          <Loader2 className="w-10 h-10 animate-spin text-indigo-400 mx-auto glow-indigo" />
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-200 tracking-wider uppercase font-mono">Synchronizing Session</h3>
            <p className="text-xs text-slate-500">Connecting securely with DeliverAI Workspace server...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <AuthScreen onAuthSuccess={(user) => setCurrentUser(user)} />;
  }

  return (
    <div className="min-h-screen flex flex-col relative overflow-x-hidden pb-10 bg-[#020514]">
      {/* Background radial effects and decorative aurora systems */}
      <div className="absolute top-[10%] left-[5%] w-[40rem] h-[40rem] rounded-full aurora-blur-1 pointer-events-none -z-20"></div>
      <div className="absolute top-[50%] right-[10%] w-[35rem] h-[35rem] rounded-full aurora-blur-2 pointer-events-none -z-20"></div>
      <div className="absolute bottom-[5%] left-[20%] w-[38rem] h-[38rem] rounded-full aurora-blur-3 pointer-events-none -z-20"></div>
      
      {/* Dynamic drifting cosmic particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none -z-10" aria-hidden="true">
        {particles.map((p) => (
          <div
            key={p.id}
            className="cosmic-particle bg-gradient-to-tr from-cyan-400 via-indigo-400 to-purple-500"
            style={{
              left: p.left,
              animationDelay: p.delay,
              animationDuration: p.duration,
              width: p.size,
              height: p.size,
              opacity: p.opacity,
            }}
          />
        ))}
      </div>

      {/* Top Main Navigation header */}
      <Navbar 
        profile={profile} 
        searchQuery={searchQuery} 
        setSearchQuery={setSearchQuery} 
        onNavigate={(tab) => {
          setSelectedDeliverable(null);
          setActiveTab(tab);
        }}
      />

      {/* Center Grid */}
      <div className="flex-1 flex" id="main-content-layout">
        {/* Left persistent sidebar */}
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={(tab) => {
            setSelectedDeliverable(null);
            setActiveTab(tab);
          }} 
          historyCount={deliverables.length}
        />

        {/* Right workspace panels */}
        <main className="flex-1 p-6 md:p-8 max-w-7xl mx-auto w-full space-y-6">
          
          {/* Global Alert Notification Drawer for Exceptions */}
          {errorMessage && (
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/35 text-red-400 text-xs flex items-start justify-between animate-fade-in" id="workspace-error-drawer">
              <div className="flex items-start space-x-2.5">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-bold leading-normal text-slate-100">API Execution Notice</h5>
                  <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{errorMessage}</p>
                </div>
              </div>
              <button 
                onClick={() => setErrorMessage(null)}
                className="text-slate-500 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-all shrink-0 ml-4"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Core Panel Router */}
          {selectedDeliverable ? (
            <ComparisonWorkspace
              deliverable={selectedDeliverable}
              onRewrite={handleRewriteModifier}
              isRewriting={isRewriting}
              onClose={() => {
                setSelectedDeliverable(null);
                setActiveTab("dashboard");
              }}
            />
          ) : (
            <>
              {activeTab === "dashboard" && (
                <DashboardPanel
                  onNavigate={(tab) => setActiveTab(tab)}
                  deliverables={deliverables}
                  onSelectDeliverable={(item) => setSelectedDeliverable(item)}
                />
              )}

              {activeTab === "generate" && (
                <InputWorkspace
                  onGenerate={handleGenerate}
                  isGenerating={isGenerating}
                  activeGenerationStep={activeGenerationStep}
                />
              )}

              {activeTab === "history" && (
                <HistoryPanel
                  deliverables={deliverables}
                  onSelect={(item) => setSelectedDeliverable(item)}
                  onDelete={handleDeleteDeliverable}
                  searchQuery={searchQuery}
                />
              )}

              {activeTab === "analytics" && (
                <AnalyticsPanel
                  deliverables={deliverables}
                />
              )}

              {activeTab === "settings" && (
                <SettingsPanel
                  profile={profile}
                  onUpdateProfile={handleUpdateProfile}
                  firebaseStatus={firebaseStatus}
                  onTriggerFirebaseSetup={triggerFirebaseProposal}
                  onLogout={handleLogout}
                />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
