import { 
  Sparkles, 
  Clock, 
  FileCheck2, 
  Activity, 
  TrendingUp, 
  FileText, 
  Mail, 
  Users, 
  BookOpen,
  ArrowRight
} from "lucide-react";
import { Deliverable } from "../types";

interface DashboardPanelProps {
  onNavigate: (tab: any) => void;
  deliverables: Deliverable[];
  onSelectDeliverable: (item: Deliverable) => void;
}

export default function DashboardPanel({ onNavigate, deliverables, onSelectDeliverable }: DashboardPanelProps) {
  // Aggregate KPI stats
  const totalCount = deliverables.length;
  const totalTimeSaved = deliverables.reduce((acc, curr) => acc + (curr.productivityInsights?.estimatedTimeSavedMinutes || 0), 0);
  
  // Calculate average scores
  const avgReadability = totalCount > 0 
    ? Math.round(deliverables.reduce((acc, curr) => acc + curr.qualityScores.readability, 0) / totalCount)
    : 0;
  const avgClarity = totalCount > 0
    ? Math.round(deliverables.reduce((acc, curr) => acc + curr.qualityScores.clarity, 0) / totalCount)
    : 0;
  const productivityScore = Math.min(100, Math.round((avgReadability + avgClarity) * 0.5 + Math.min(15, totalCount * 4)));
  const workflowEfficiency = totalCount > 0 ? "94.2%" : "N/A";

  const recentDeliverables = deliverables.slice(0, 3);

  const getDeliverableIcon = (type: string) => {
    switch (type) {
      case "report": return <FileText className="w-5 h-5 text-indigo-400" />;
      case "email": return <Mail className="w-5 h-5 text-purple-400" />;
      case "meeting_minutes": return <Users className="w-5 h-5 text-cyan-400" />;
      case "study_notes": return <BookOpen className="w-5 h-5 text-emerald-400" />;
      default: return <FileText className="w-5 h-5 text-slate-400" />;
    }
  };

  const getDeliverableLabel = (type: string) => {
    switch (type) {
      case "report": return "Professional Report";
      case "email": return "Professional Email";
      case "meeting_minutes": return "Meeting Minutes";
      case "study_notes": return "Study Notes";
      default: return type;
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" id="dashboard-panel">
      {/* Premium Hero Section */}
      <section 
        className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-[#0c0a3e]/40 via-[#030014] to-[#010b1a]/60 p-8 md:p-12 shadow-2xl"
        id="dashboard-hero"
      >
        {/* Floating background blobs */}
        <div className="absolute top-1/4 right-1/4 w-72 h-72 rounded-full aurora-blur-1 pointer-events-none"></div>
        <div className="absolute bottom-10 right-12 w-64 h-64 rounded-full aurora-blur-2 pointer-events-none"></div>

        <div className="max-w-2xl relative z-10 space-y-4">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-spin-slow" />
            <span>Generative AI Engine v3.5 Active</span>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-extrabold font-display tracking-tight text-white leading-tight">
            Transform Raw Data Into <br/>
            <span className="bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-500 bg-clip-text text-transparent glow-indigo">
              Professional Deliverables
            </span>
          </h2>
          
          <p className="text-slate-400 text-base md:text-lg font-light leading-relaxed">
            Convert scattered voice recordings, rough meeting drafts, text transcripts, and documents into executive reports, polished emails, structured minutes, and detailed study notes in seconds.
          </p>

          <div className="pt-4 flex flex-wrap gap-4">
            <button
              onClick={() => onNavigate("generate")}
              className="flex items-center space-x-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-semibold px-6 py-3.5 rounded-xl transition-all duration-300 transform hover:scale-[1.02] shadow-[0_0_20px_rgba(99,102,241,0.4)] hover:shadow-[0_0_30px_rgba(99,102,241,0.65)] uppercase tracking-wider text-xs"
              id="hero-cta-btn"
            >
              <span>Generate Deliverable</span>
              <Sparkles className="w-4 h-4 text-cyan-200" />
            </button>
            
            <button
              onClick={() => onNavigate("history")}
              className="flex items-center space-x-2 bg-slate-950/60 hover:bg-slate-900 border border-white/10 hover:border-indigo-500/30 text-slate-300 hover:text-white px-6 py-3.5 rounded-xl transition-all font-semibold uppercase tracking-wider text-xs"
              id="hero-secondary-btn"
            >
              <span>View History</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Micro elements illustration on right */}
        <div className="absolute right-10 bottom-0 top-0 hidden lg:flex items-center justify-center opacity-40 xl:opacity-85 pointer-events-none">
          <div className="relative w-80 h-80 rounded-full border border-indigo-500/10 flex items-center justify-center">
            {/* Inner rings */}
            <div className="absolute w-60 h-60 rounded-full border border-purple-500/20 animate-spin-slow flex items-center justify-center">
              <div className="absolute top-0 w-3 h-3 bg-cyan-400 rounded-full blur-xs"></div>
              <div className="absolute bottom-0 w-3.5 h-3.5 bg-purple-400 rounded-full blur-xs"></div>
            </div>
            <div className="absolute w-44 h-44 rounded-full border border-indigo-500/30 flex items-center justify-center animate-spin-reverse-slow">
              <div className="absolute left-0 w-2.5 h-2.5 bg-indigo-400 rounded-full"></div>
            </div>
            
            {/* Core glowing jewel */}
            <div className="relative w-24 h-24 bg-gradient-to-tr from-indigo-500/30 to-purple-500/25 rounded-2xl flex items-center justify-center border border-white/20 shadow-2xl shadow-indigo-500/40">
              <Sparkles className="w-10 h-10 text-cyan-300 animate-pulse" />
            </div>
          </div>
        </div>
      </section>

      {/* KPI Analytics Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5" id="dashboard-kpis">
        {/* KPI 1 — Time Saved */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-6 transition-all duration-300 shadow-md group relative overflow-hidden" id="kpi-time-saved">
          {/* Neon radial backlight */}
          <div className="absolute -top-10 -right-10 w-28 h-28 bg-cyan-500/10 rounded-full blur-2xl group-hover:bg-cyan-500/20 transition-all duration-500"></div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 font-sans text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-pulse"></span>
              <span>Time Saved</span>
            </span>
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 transition-all duration-300 group-hover:bg-cyan-500 group-hover:text-slate-950 group-hover:scale-110 group-hover:shadow-[0_0_15px_rgba(6,182,212,0.4)]">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1 relative z-10">
            <p className="text-3xl font-bold font-display text-white tracking-tight leading-none group-hover:text-cyan-300 transition-colors glow-cyan">
              {totalTimeSaved > 60 ? `${Math.floor(totalTimeSaved / 60)}h ${totalTimeSaved % 60}m` : `${totalTimeSaved} mins`}
            </p>
            <p className="text-xs text-slate-500 font-medium">Accumulated workspace effort</p>
          </div>
          {/* Interactive neon accent slider bar */}
          <div className="absolute bottom-0 left-0 h-[3px] bg-gradient-to-r from-cyan-500 to-cyan-300 w-1/3 group-hover:w-full transition-all duration-500 ease-out"></div>
        </div>

        {/* KPI 2 — Deliverables Generated */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-6 transition-all duration-300 shadow-md group relative overflow-hidden" id="kpi-deliverables-count">
          {/* Neon radial backlight */}
          <div className="absolute -top-10 -right-10 w-28 h-28 bg-indigo-500/10 rounded-full blur-2xl group-hover:bg-indigo-500/20 transition-all duration-500"></div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 font-sans text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-pulse"></span>
              <span>Deliverables</span>
            </span>
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 transition-all duration-300 group-hover:bg-indigo-500 group-hover:text-slate-950 group-hover:scale-110 group-hover:shadow-[0_0_15px_rgba(99,102,241,0.4)]">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1 relative z-10">
            <p className="text-3xl font-bold font-display text-white tracking-tight leading-none group-hover:text-indigo-300 transition-colors glow-indigo">
              {totalCount} Documents
            </p>
            <p className="text-xs text-slate-500 font-medium">Indexed within cloud storage</p>
          </div>
          {/* Interactive neon accent slider bar */}
          <div className="absolute bottom-0 left-0 h-[3px] bg-gradient-to-r from-indigo-500 to-indigo-300 w-1/3 group-hover:w-full transition-all duration-500 ease-out"></div>
        </div>

        {/* KPI 3 — Productivity Score */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-6 transition-all duration-300 shadow-md group relative overflow-hidden" id="kpi-productivity-score">
          {/* Neon radial backlight */}
          <div className="absolute -top-10 -right-10 w-28 h-28 bg-purple-500/10 rounded-full blur-2xl group-hover:bg-purple-500/20 transition-all duration-500"></div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 font-sans text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-pulse"></span>
              <span>Efficiency Rating</span>
            </span>
            <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 transition-all duration-300 group-hover:bg-purple-500 group-hover:text-slate-950 group-hover:scale-110 group-hover:shadow-[0_0_15px_rgba(168,85,247,0.4)]">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1 relative z-10">
            <p className="text-3xl font-bold font-display text-white tracking-tight leading-none group-hover:text-purple-300 transition-colors [text-shadow:0_0_15px_rgba(168,85,247,0.4)]">
              {productivityScore}%
            </p>
            <p className="text-xs text-slate-500 font-medium">Multi-agent quality score</p>
          </div>
          {/* Interactive neon accent slider bar */}
          <div className="absolute bottom-0 left-0 h-[3px] bg-gradient-to-r from-purple-500 to-purple-300 w-1/3 group-hover:w-full transition-all duration-500 ease-out"></div>
        </div>

        {/* KPI 4 — Workflow Efficiency */}
        <div className="glass-panel glass-panel-hover rounded-2xl p-6 transition-all duration-300 shadow-md group relative overflow-hidden" id="kpi-efficiency">
          {/* Neon radial backlight */}
          <div className="absolute -top-10 -right-10 w-28 h-28 bg-pink-500/10 rounded-full blur-2xl group-hover:bg-pink-500/20 transition-all duration-500"></div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 font-sans text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-pulse"></span>
              <span>Optimization Rate</span>
            </span>
            <div className="p-2.5 rounded-xl bg-pink-500/10 border border-pink-500/30 text-pink-400 transition-all duration-300 group-hover:bg-pink-500 group-hover:text-slate-950 group-hover:scale-110 group-hover:shadow-[0_0_15px_rgba(236,72,153,0.4)]">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1 relative z-10">
            <p className="text-3xl font-bold font-display text-white tracking-tight leading-none group-hover:text-pink-300 transition-colors [text-shadow:0_0_15px_rgba(236,72,153,0.4)]">
              {workflowEfficiency}
            </p>
            <p className="text-xs text-slate-500 font-medium">Active server speed capacity</p>
          </div>
          {/* Interactive neon accent slider bar */}
          <div className="absolute bottom-0 left-0 h-[3px] bg-gradient-to-r from-pink-500 to-pink-300 w-1/3 group-hover:w-full transition-all duration-500 ease-out"></div>
        </div>
      </section>

      {/* Grid: Recent and Info */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="recent-assets-grid">
        {/* Left 2 cols: Recent Deliverables */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold font-display text-white">Recent Outputs</h3>
            <button 
              onClick={() => onNavigate("history")} 
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center space-x-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentDeliverables.length === 0 ? (
            <div className="glass-panel rounded-2xl p-10 text-center text-slate-500 space-y-4">
              <FileText className="w-12 h-12 mx-auto text-slate-600 animate-pulse" />
              <div>
                <p className="font-semibold text-slate-300">No deliverables generated yet</p>
                <p className="text-xs text-slate-500 mt-1">Get started by building your first document using Gemini AI!</p>
              </div>
              <button
                onClick={() => onNavigate("generate")}
                className="mx-auto flex items-center space-x-1.5 py-2 px-4 rounded-xl text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 hover:bg-indigo-500 hover:text-white transition-all uppercase tracking-wider font-bold"
              >
                <span>Launch Generator</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4" id="recent-list">
              {recentDeliverables.map((item) => (
                <div 
                  key={item.id}
                  onClick={() => onSelectDeliverable(item)}
                  className="glass-panel glass-panel-hover rounded-2xl p-5 flex items-center justify-between border border-white/5 cursor-pointer hover:-translate-y-0.5 transition-all duration-300 group"
                >
                  <div className="flex items-center space-x-4 min-w-0">
                    <div className="p-3 bg-white/5 rounded-xl border border-white/10 transition-colors group-hover:bg-indigo-500/10 group-hover:border-indigo-500/20">
                      {getDeliverableIcon(item.deliverableType)}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-slate-500 font-mono tracking-wide uppercase font-semibold">
                        {getDeliverableLabel(item.deliverableType)} • <span className="text-indigo-400 font-bold">{item.tone}</span>
                      </p>
                      <h4 className="text-slate-100 font-semibold truncate text-[15px] mt-1 pr-4">{item.summary}</h4>
                      <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                        {new Date(item.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-5 shrink-0 pl-1">
                    {/* Quality badge ticker */}
                    <div className="text-right">
                      <div className="text-xs font-bold text-emerald-400 font-mono bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md leading-none">
                        {Math.round((item.qualityScores.readability + item.qualityScores.clarity) / 2)}% QA
                      </div>
                      <p className="text-[10px] text-slate-500 font-mono mt-1 leading-none">{item.productivityInsights.estimatedTimeSavedMinutes}m saved</p>
                    </div>
                    {/* Arrow hint */}
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition-transform duration-300 group-hover:translate-x-1" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right 1 col: Premium System Guide */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold font-display text-white">System Operations</h3>
          <div className="glass-panel rounded-2xl p-6 bg-gradient-to-tr from-indigo-950/20 to-purple-950/20 border border-white/5 space-y-6">
            <div className="flex items-start space-x-3.5">
              <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-300 text-xs font-bold font-mono">1</span>
              <div>
                <h4 className="text-sm font-semibold text-slate-200">Submit Information</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">Paste outlines, upload standard files, transcripts, or upload audio recordings for instantaneous indexing.</p>
              </div>
            </div>

            <div className="flex items-start space-x-3.5">
              <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-lg bg-pink-500/20 text-pink-300 text-xs font-bold font-mono">2</span>
              <div>
                <h4 className="text-sm font-semibold text-slate-200">Comparison Output</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">Review Professional, Executive, and Academic copies generated simultaneously side-by-side.</p>
              </div>
            </div>

            <div className="flex items-start space-x-3.5">
              <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-300 text-xs font-bold font-mono">3</span>
              <div>
                <h4 className="text-sm font-semibold text-slate-200">Refine & Export</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">Refine content with single-click rewrites, then download directly as rich PDF, plain text or Word Document structures.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
