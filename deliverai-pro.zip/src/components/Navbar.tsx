import { Sparkles, Bell, Search, ShieldCheck } from "lucide-react";
import { UserProfile } from "../types";

interface NavbarProps {
  profile: UserProfile;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onNavigate: (tab: any) => void;
}

export default function Navbar({ profile, searchQuery, setSearchQuery, onNavigate }: NavbarProps) {
  return (
    <header className="glass-panel sticky top-0 z-40 w-full px-6 py-4 flex items-center justify-between border-b border-white/10 shadow-lg shadow-indigo-950/20">
      {/* Search, Brand and indicators */}
      <div className="flex items-center space-x-3">
        <div 
          onClick={() => onNavigate("dashboard")}
          className="flex items-center space-x-2 cursor-pointer group"
          id="navbar-logo"
        >
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-cyan-400 p-[1.5px] shadow-[0_0_15px_rgba(99,102,241,0.4)] transition-transform duration-300 group-hover:scale-105">
            <div className="flex items-center justify-center w-full h-full rounded-[10px] bg-[#030014]">
              <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <h1 className="text-xl font-bold font-display tracking-tight bg-gradient-to-r from-white via-slate-100 to-cyan-300 bg-clip-text text-transparent">
              Deliver<span className="text-indigo-400 glow-indigo">AI</span>
            </h1>
            <p className="text-[9px] font-mono tracking-wider text-cyan-400 uppercase leading-none mt-0.5">PRO WORKSPACE</p>
          </div>
        </div>
      </div>

      {/* Global Search Interface */}
      <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
        <div className="relative w-full">
          <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search deliverables, tasks, or history..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950/60 text-slate-200 pl-10 pr-4 py-2 text-sm rounded-xl border border-white/10 outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/30 transition-all placeholder:text-slate-500"
            id="navbar-search"
          />
        </div>
      </div>

      {/* Profile & Notifications */}
      <div className="flex items-center space-x-4">
        <label className="hidden sm:flex items-center space-x-1.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs px-2.5 py-1 rounded-full font-medium" id="api-status-badge">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Gemini Cloud Active</span>
        </label>

        {/* Notification system */}
        <button 
          className="relative p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/5 transition-colors border border-white/5"
          id="navbar-notifications"
          title="Notifications"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-500 rounded-full animate-ping"></span>
          <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-500 rounded-full"></span>
        </button>

        {/* User profile dropdown container */}
        <div 
          onClick={() => onNavigate("settings")}
          className="flex items-center space-x-3 cursor-pointer p-1.5 pr-3 rounded-xl border border-white/5 hover:bg-white/5 transition-all text-left"
          id="navbar-profile"
        >
          <img
            src={profile.avatarUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"}
            alt={profile.name}
            className="w-8 h-8 rounded-lg object-cover ring-1 ring-indigo-500/40"
            referrerPolicy="no-referrer"
          />
          <div className="hidden lg:block">
            <p className="text-xs font-semibold text-slate-200 leading-tight">{profile.name}</p>
            <p className="text-[10px] text-slate-400 font-mono leading-none mt-0.5">{profile.email}</p>
          </div>
        </div>
      </div>
    </header>
  );
}
