import { useState } from "react";
import { generateStyledPDF } from "../utils/pdfGenerator";
import { 
  Sparkles, 
  Copy, 
  Download, 
  Check, 
  Maximize2, 
  Minimize2, 
  Cpu, 
  TrendingUp, 
  CheckSquare, 
  Clock, 
  Calendar,
  Layers,
  FileText,
  Mail,
  Zap,
  RotateCcw,
  BookOpen
} from "lucide-react";
import { Deliverable } from "../types";
import SmartMarkdownRenderer from "./SmartMarkdownRenderer";

interface ComparisonWorkspaceProps {
  deliverable: Deliverable;
  onRewrite: (modifier: string) => void;
  isRewriting: boolean;
  onSaveToHistory?: (item: Deliverable) => void;
  onClose: () => void;
}

function parseEmailParts(rawText: string) {
  const lines = rawText.split("\n");
  let subject = "DeliverAI Pro Outreach Output";
  let bodyLines: string[] = [];
  let foundSubject = false;
  
  // Regex to strip labels directly in the client renderer just in case
  const labelPrefixRegex = /^\s*(subject|subject\s*line|greeting|closing|signature|body|body\s*paragraph\s*[123]|sender|recipient)\s*:\s*/i;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    const cleanLine = trimmed.replace(/^\*+\s*|\*+\s*$/g, "").trim();
    
    if (!foundSubject && (cleanLine.toLowerCase().startsWith("subject:") || cleanLine.toLowerCase().startsWith("subject line:"))) {
      subject = cleanLine.replace(/^(subject:|subject line:)\s*/i, "").trim().replace(labelPrefixRegex, "");
      foundSubject = true;
    } else {
      const isLabelLine = cleanLine.toLowerCase().startsWith("greeting:") || 
                           cleanLine.toLowerCase().startsWith("closing:") || 
                           cleanLine.toLowerCase().startsWith("signature:");
      
      if (isLabelLine) {
        const stripped = line.replace(labelPrefixRegex, "");
        bodyLines.push(stripped);
      } else {
        bodyLines.push(line);
      }
    }
  }
  
  const bodyText = bodyLines.join("\n").trim();
  return { subject, body: bodyText };
}

function EmailVisualizer({ 
  rawText, 
  toneTitle, 
  deliverable, 
  handleExport 
}: { 
  rawText: string, 
  toneTitle: string, 
  deliverable: Deliverable,
  handleExport: (text: string, title: string, mode: "txt" | "doc" | "pdf") => void
}) {
  const [copied, setCopied] = useState(false);
  const { subject, body } = parseEmailParts(rawText);

  const handleCopyRich = async () => {
    // Convert lines into HTML paragraphs/newlines preserving structure
    const bodyParagraphs = body.split("\n\n").map(p => {
      const formatted = p.trim()
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
        .replace(/\nLine/g, "<br>");
      return `<p style="margin: 0 0 12px 0; font-family: Helvetica, Arial, sans-serif;">${formatted}</p>`;
    }).join("");

    const fullPasteHtml = `
      <div style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6; color: #1e293b;">
        <p style="margin: 0 0 8px 0; font-weight: bold;">Subject: ${subject}</p>
        <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 12px 0;" />
        ${bodyParagraphs}
      </div>
    `;

    const plainText = `Subject: ${subject}\n\n${body}`;

    try {
      const blobHtml = new Blob([fullPasteHtml], { type: "text/html" });
      const blobText = new Blob([plainText], { type: "text/plain" });
      const data = [new ClipboardItem({
        "text/html": blobHtml,
        "text/plain": blobText,
      })];
      await navigator.clipboard.write(data);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      await navigator.clipboard.writeText(plainText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4" id={`email-visualizer-${toneTitle.toLowerCase()}`}>
      <div className="bg-slate-950/50 rounded-xl border border-white/5 p-4 space-y-3 font-sans">
        <div className="space-y-2 text-xs border-b border-white/5 pb-3">
          <div className="flex items-center text-slate-400">
            <span className="w-16 font-mono text-[10px] text-slate-500 uppercase">From:</span>
            <span className="text-slate-300 font-semibold font-mono">deliverai-pro-assistant@services.ai</span>
          </div>
          <div className="flex items-center text-slate-400">
            <span className="w-16 font-mono text-[10px] text-slate-500 uppercase">Subject:</span>
            <span className="text-cyan-300 font-bold select-all bg-cyan-950/20 px-2 py-1 rounded border border-cyan-500/10 flex-1">{subject}</span>
          </div>
        </div>

        <div className="text-slate-300 text-xs leading-relaxed select-text min-h-[160px] whitespace-pre-wrap pt-1 font-sans">
          {body}
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopyRich}
            className="px-3.5 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20 text-indigo-300 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer"
            id={`copy-email-rich-${toneTitle.toLowerCase()}`}
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-indigo-400" />
                <span>Copy Email</span>
              </>
            )}
          </button>

          <a
            href={`https://mail.google.com/mail/?view=cm&fs=1&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3.5 py-1.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-300 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all"
            id={`gmail-compose-${toneTitle.toLowerCase()}`}
          >
            <Mail className="w-3.5 h-3.5 text-red-400" />
            <span>Open in Gmail</span>
          </a>
        </div>

        <div className="flex items-center space-x-2 text-[11px] font-medium text-slate-400">
          <span className="font-mono text-[10px] text-slate-500 uppercase">Export:</span>
          <button
            onClick={() => handleExport(rawText, toneTitle, "txt")}
            className="hover:text-cyan-400 flex items-center space-x-1"
            id={`export-txt-${toneTitle.toLowerCase()}`}
          >
            <Download className="w-3 h-3 text-cyan-400" />
            <span>TXT</span>
          </button>
          <span>•</span>
          <button
            onClick={() => handleExport(rawText, toneTitle, "doc")}
            className="hover:text-indigo-400 flex items-center space-x-1"
            id={`export-word-${toneTitle.toLowerCase()}`}
          >
            <Download className="w-3 h-3 text-indigo-400" />
            <span>Word</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// Custom simple parser to transform basic Markdown into pristine HTML
function SimpleMarkdown({ text }: { text: string }) {
  const parseMarkdown = (md: string) => {
    // Process headers
    let html = md
      .replace(/^### (.*$)/gim, '<h4 class="text-sm font-bold text-indigo-350 tracking-wide uppercase mt-4 mb-2">$1</h4>')
      .replace(/^## (.*$)/gim, '<h3 class="text-base font-bold text-white tracking-tight border-b border-white/5 pb-1 mt-5 mb-2">$1</h3>')
      .replace(/^# (.*$)/gim, '<h2 class="text-lg font-bold text-cyan-300 font-display mt-6 mb-3">$1</h2>');

    // Bold tags
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-white bg-indigo-500/10 px-1 rounded">$1</strong>');

    // Bullet points
    html = html.replace(/^\* (.*$)/gim, '<li class="ml-4 list-disc text-slate-350 text-xs py-1 leading-relaxed">$1</li>');
    html = html.replace(/^- (.*$)/gim, '<li class="ml-4 list-disc text-slate-350 text-xs py-1 leading-relaxed">$1</li>');

    // Render remaining lines as standard text blocks
    const lines = html.split("\n");
    const formattedLines = lines.map((line) => {
      if (line.trim().startsWith("<h") || line.trim().startsWith("<li") || line.trim() === "") {
        return line;
      }
      return `<p class="text-xs text-slate-400 font-normal leading-relaxed mt-1.5">${line}</p>`;
    });

    return formattedLines.join("\n");
  };

  return (
    <div 
      className="space-y-1 select-text"
      dangerouslySetInnerHTML={{ __html: parseMarkdown(text) }}
    />
  );
}

export default function ComparisonWorkspace({ 
  deliverable, 
  onRewrite, 
  isRewriting, 
  onSaveToHistory,
  onClose 
}: ComparisonWorkspaceProps) {
  const [copiedTab, setCopiedTab] = useState<string | null>(null);
  const [expandedCard, setExpandedCard] = useState<"professional" | "executive" | "academic" | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(key);
    setTimeout(() => setCopiedTab(null), 2000);
  };

  const handleExport = (text: string, title: string, mode: "txt" | "doc" | "pdf") => {
    const cleanTitle = `${deliverable.deliverableType.toUpperCase()}_${title}_VERSION`;
    if (mode === "txt") {
      const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${cleanTitle}.txt`;
      link.click();
    } else if (mode === "doc") {
      const formattedContent = text.replace(/\n/g, "<br>");
      const rawHtml = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head><title>${cleanTitle}</title><style>body { font-family: system-ui, Arial; font-size: 11pt; line-height: 1.5; color: #1e293b; }</style></head>
        <body>
          <h2>DeliverAI Pro Product Deliverable</h2>
          <p><strong>Deliverable Type:</strong> ${deliverable.deliverableType.toUpperCase()}</p>
          <p><strong>Original Creation:</strong> ${new Date(deliverable.createdAt).toLocaleString()}</p>
          <hr/>
          ${formattedContent}
        </body>
        </html>
      `;
      const blob = new Blob([rawHtml], { type: "application/msword" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${cleanTitle}.doc`;
      link.click();
    } else if (mode === "pdf") {
      try {
        generateStyledPDF(deliverable, text, title);
      } catch (err) {
        console.error("PDF generation failed:", err);
        // Fallback to standard print popup
        const printWin = window.open("", "_blank");
        if (printWin) {
          printWin.document.write(`
            <html>
            <head>
              <title>${cleanTitle}</title>
              <style>
                body { font-family: system-ui, Arial, sans-serif; padding: 40px; color: #1e293b; line-height: 1.6; }
                hr { border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0; }
                h1 { font-size: 20px; color: #0f172a; margin-bottom: 5px; }
              </style>
            </head>
            <body>
              <h1>${cleanTitle}</h1>
              <hr/>
              <div style="white-space: pre-wrap;">${text}</div>
              <script>window.onload = function() { window.print(); }</script>
            </body>
            </html>
          `);
          printWin.document.close();
        }
      }
    }
  };

  const getDialColor = (score: number) => {
    if (score >= 90) return "stroke-emerald-400";
    if (score >= 75) return "stroke-indigo-400";
    return "stroke-amber-400";
  };

  return (
    <div className="space-y-8 animate-fade-in" id="comparison-view-container">
      {/* Top action header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-[10px] uppercase font-mono tracking-widest bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded">
              Generated Successfully
            </span>
          </div>
          <h3 className="text-xl font-bold font-display text-white mt-1">Deliverable Review Suite</h3>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold uppercase tracking-wider bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 hover:border-slate-500 rounded-lg transition-all"
            id="close-suite-btn"
          >
            ← Workspace
          </button>
        </div>
      </div>

      {/* Speed Refinement Box (One-Click Rewrite Tools) */}
      <section className="glass-panel p-5 rounded-2xl border border-white/5 space-y-4" id="speed-rewrite-tools">
        <div className="flex items-center space-x-2">
          <Zap className="w-4 h-4 text-cyan-400 animate-pulse" />
          <h4 className="text-sm font-semibold text-slate-200">One-Click AI Refinement</h4>
        </div>
        <p className="text-xs text-slate-500">Regenerate current outputs with pre-configured expert modifiers instantly.</p>
        
        <div className="flex flex-wrap gap-2.5">
          {[
            { label: "More Professional", code: "Make it extremely formal and business-focused with expert vocab" },
            { label: "More Detailed", code: "Exhaustively elaborate all aspects with definitions, data, and background" },
            { label: "More Concise", code: "Synthesize and write in strict, ultra-short punchy points" },
            { label: "Executive Rewrite", code: "Refine and rewrite utilizing a C-suite executive style" },
            { label: "Academic Rewrite", code: "Explain and rewrite using detailed and definitions Academic styled context" }
          ].map((tool, i) => (
            <button
              key={i}
              onClick={() => !isRewriting && onRewrite(tool.code)}
              disabled={isRewriting}
              className="px-3.5 py-2 hover:py-2 rounded-xl text-xs font-medium bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/5 hover:border-indigo-500/30 transition-all flex items-center space-x-1.5 cursor-pointer disabled:cursor-not-allowed"
              id={`rewrite-tool-${i}`}
            >
              {isRewriting ? (
                <div className="w-3 h-3 rounded-full border border-slate-500 border-t-white animate-spin"></div>
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              )}
              <span>{tool.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Signature Feature: Deliverable Comparison Mode Side-by-Side Cards */}
      <section className="space-y-4" id="comparison-deck-section">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-indigo-400" />
            <h4 className="text-sm font-bold tracking-tight text-white font-display">Deliverable Comparison Deck</h4>
          </div>
          <p className="text-[11px] font-mono text-cyan-400 animate-pulse uppercase">Simultaneous Trio Output</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="comparison-deck-grid">
          {/* Card 1 — Professional Version */}
          {(expandedCard === null || expandedCard === "professional") && (
            <div 
              className={`glass-panel rounded-2xl flex flex-col border border-indigo-500/20 shadow-[0_0_20px_rgba(99,102,241,0.06)] hover:border-indigo-500/40 transition-all duration-300 ${
                expandedCard === "professional" ? "lg:col-span-3 min-h-[500px]" : "min-h-[440px]"
              }`}
              id="comparison-card-professional"
            >
              {/* Header */}
              <div className="p-4 border-b border-white/5 bg-indigo-950/15 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 bg-indigo-500 rounded-full"></div>
                  <h5 className="text-xs font-bold leading-none font-display text-white uppercase tracking-wider">Professional Format</h5>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => handleCopy(deliverable.professional, "prof")}
                    className="p-1.5 rounded-lg bg-[#030014] text-slate-400 hover:text-white border border-white/5 transition-all"
                    title="Copy to Clipboard"
                  >
                    {copiedTab === "prof" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <button 
                    onClick={() => setExpandedCard(expandedCard === "professional" ? null : "professional")}
                    className="p-1.5 rounded-lg bg-[#030014] text-slate-400 hover:text-white border border-white/5 transition-all"
                  >
                    {expandedCard === "professional" ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              
              {/* Body Content */}
              <div className="p-5 flex-1 overflow-y-auto max-h-[400px]">
                {deliverable.deliverableType === "email" ? (
                  <EmailVisualizer 
                    rawText={deliverable.professional}
                    toneTitle="Professional"
                    deliverable={deliverable}
                    handleExport={handleExport}
                  />
                ) : (
                  <SmartMarkdownRenderer text={deliverable.professional} />
                )}
              </div>

              {/* Action Foots */}
              {deliverable.deliverableType !== "email" && (
                <div className="p-3 bg-indigo-950/10 border-t border-white/5 flex items-center justify-between text-xs font-medium text-slate-400">
                  <span>Formal & Detailed</span>
                  <div className="flex items-center space-x-2">
                    <button 
                      onClick={() => handleExport(deliverable.professional, "Professional", "txt")}
                      className="hover:text-cyan-400 flex items-center space-x-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>TXT</span>
                    </button>
                    <span>•</span>
                    <button 
                      onClick={() => handleExport(deliverable.professional, "Professional", "doc")}
                      className="hover:text-indigo-400 flex items-center space-x-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>DOC</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Card 2 — Executive Version */}
          {(expandedCard === null || expandedCard === "executive") && (
            <div 
              className={`glass-panel rounded-2xl flex flex-col border border-purple-500/20 shadow-[0_0_20px_rgba(168,85,247,0.06)] hover:border-purple-500/40 transition-all duration-300 ${
                expandedCard === "executive" ? "lg:col-span-3 min-h-[500px]" : "min-h-[440px]"
              }`}
              id="comparison-card-executive"
            >
              <div className="p-4 border-b border-white/5 bg-purple-950/15 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 bg-purple-500 rounded-full"></div>
                  <h5 className="text-xs font-bold leading-none font-display text-white uppercase tracking-wider">Executive Format</h5>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => handleCopy(deliverable.executive, "exec")}
                    className="p-1.5 rounded-lg bg-[#030014] text-slate-400 hover:text-white border border-white/5 transition-all"
                    title="Copy to Clipboard"
                  >
                    {copiedTab === "exec" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <button 
                    onClick={() => setExpandedCard(expandedCard === "executive" ? null : "executive")}
                    className="p-1.5 rounded-lg bg-[#030014] text-slate-400 hover:text-white border border-white/5 transition-all"
                  >
                    {expandedCard === "executive" ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="p-5 flex-1 overflow-y-auto max-h-[400px]">
                {deliverable.deliverableType === "email" ? (
                  <EmailVisualizer 
                    rawText={deliverable.executive}
                    toneTitle="Executive"
                    deliverable={deliverable}
                    handleExport={handleExport}
                  />
                ) : (
                  <SmartMarkdownRenderer text={deliverable.executive} />
                )}
              </div>

              {deliverable.deliverableType !== "email" && (
                <div className="p-3 bg-purple-950/10 border-t border-white/5 flex items-center justify-between text-xs font-medium text-slate-400">
                  <span>Concise & BLUF Core</span>
                  <div className="flex items-center space-x-2">
                    <button 
                      onClick={() => handleExport(deliverable.executive, "Executive", "txt")}
                      className="hover:text-cyan-400 flex items-center space-x-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>TXT</span>
                    </button>
                    <span>•</span>
                    <button 
                      onClick={() => handleExport(deliverable.executive, "Executive", "doc")}
                      className="hover:text-indigo-400 flex items-center space-x-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>DOC</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Card 3 — Academic Version */}
          {(expandedCard === null || expandedCard === "academic") && (
            <div 
              className={`glass-panel rounded-2xl flex flex-col border border-emerald-500/20 shadow-[0_0_20px_rgba(16,185,129,0.06)] hover:border-emerald-500/40 transition-all duration-300 ${
                expandedCard === "academic" ? "lg:col-span-3 min-h-[500px]" : "min-h-[440px]"
              }`}
              id="comparison-card-academic"
            >
              <div className="p-4 border-b border-white/5 bg-emerald-950/15 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full"></div>
                  <h5 className="text-xs font-bold leading-none font-display text-white uppercase tracking-wider">Academic Format</h5>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => handleCopy(deliverable.academic, "acad")}
                    className="p-1.5 rounded-lg bg-[#030014] text-slate-400 hover:text-white border border-white/5 transition-all"
                    title="Copy to Clipboard"
                  >
                    {copiedTab === "acad" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <button 
                    onClick={() => setExpandedCard(expandedCard === "academic" ? null : "academic")}
                    className="p-1.5 rounded-lg bg-[#030014] text-slate-400 hover:text-white border border-white/5 transition-all"
                  >
                    {expandedCard === "academic" ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="p-5 flex-1 overflow-y-auto max-h-[400px]">
                {deliverable.deliverableType === "email" ? (
                  <EmailVisualizer 
                    rawText={deliverable.academic}
                    toneTitle="Academic"
                    deliverable={deliverable}
                    handleExport={handleExport}
                  />
                ) : (
                  <SmartMarkdownRenderer text={deliverable.academic} />
                )}
              </div>

              {deliverable.deliverableType !== "email" && (
                <div className="p-3 bg-emerald-950/10 border-t border-white/5 flex items-center justify-between text-xs font-medium text-slate-400">
                  <span>Thematic & Conceptual</span>
                  <div className="flex items-center space-x-2">
                    <button 
                      onClick={() => handleExport(deliverable.academic, "Academic", "txt")}
                      className="hover:text-cyan-400 flex items-center space-x-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>TXT</span>
                    </button>
                    <span>•</span>
                    <button 
                      onClick={() => handleExport(deliverable.academic, "Academic", "doc")}
                      className="hover:text-indigo-400 flex items-center space-x-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>DOC</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Grid for Quality Scores & Productivity Insights Panels */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="quality-insights-layout">
        {/* Left 1 Column: AI Quality Analysis gauges */}
        <div className="glass-panel rounded-2xl p-6 border border-white/5 space-y-6">
          <div className="flex items-center space-x-2 pb-2 border-b border-white/5">
            <Cpu className="w-4 h-4 text-cyan-400 animate-pulse" />
            <h4 className="text-sm font-bold tracking-tight text-white font-display">AI Quality Evaluation</h4>
          </div>

          <div className="grid grid-cols-2 gap-4" id="circular-scores-grid">
            {[
              { label: "Readability", key: "readability", score: deliverable.qualityScores.readability },
              { label: "Professionalism", key: "professionalism", score: deliverable.qualityScores.professionalism },
              { label: "Completeness", key: "completeness", score: deliverable.qualityScores.completeness },
              { label: "Clarity Scope", key: "clarity", score: deliverable.qualityScores.clarity }
            ].map((metric) => {
              const radius = 18;
              const circumference = 2 * Math.PI * radius;
              const strokeDashoffset = circumference - (metric.score / 100) * circumference;
              
              return (
                <div key={metric.key} className="flex flex-col items-center p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                  {/* Circular Dial using SVG */}
                  <div className="relative w-14 h-14 flex items-center justify-center">
                    <svg className="w-full h-full transform -rotate-90">
                      <circle
                        cx="28"
                        cy="28"
                        r={radius}
                        className="stroke-slate-800"
                        strokeWidth="3.5"
                        fill="transparent"
                      />
                      <circle
                        cx="28"
                        cy="28"
                        r={radius}
                        className={`${getDialColor(metric.score)} transition-all duration-500`}
                        strokeWidth="3.5"
                        fill="transparent"
                        strokeDasharray={circumference}
                        strokeDashoffset={strokeDashoffset}
                        strokeLinecap="round"
                      />
                    </svg>
                    <span className="absolute text-xs font-bold font-mono text-slate-100">{metric.score}%</span>
                  </div>
                  <span className="text-[11px] font-medium text-slate-400 mt-2">{metric.label}</span>
                </div>
              );
            })}
          </div>

          {/* Full Page Download Action Trigger */}
          <div className="pt-3 border-t border-white/5">
            <button
              onClick={() => handleExport(deliverable.professional, "Professional", "pdf")}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-bold uppercase tracking-wider bg-white/5 text-slate-200 border border-white/10 hover:border-indigo-500/40 hover:text-white hover:bg-indigo-500/10 transition-all flex items-center justify-center space-x-2"
              id="suite-print-pdf-trigger"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>Download Professional PDF Report</span>
            </button>
          </div>
        </div>

        {/* Right 2 Columns: AI Productivity Insights */}
        <div className="lg:col-span-2 glass-panel rounded-2xl p-6 border border-white/5 space-y-6">
          <div className="flex items-center justify-between pb-2 border-b border-white/5">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              <h4 className="text-sm font-bold tracking-tight text-white font-display">AI Productivity Insights</h4>
            </div>
            {/* Display time saved count up */}
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 font-mono text-indigo-400 text-xs font-bold">
              <Clock className="w-3.5 h-3.5" />
              <span>+{deliverable.productivityInsights.estimatedTimeSavedMinutes} Mins Saved</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6" id="insights-checklist-sections">
            {/* Column 1: Tasks Identified */}
            <div className="space-y-3">
              <div className="flex items-center space-x-1.5 text-indigo-400">
                <CheckSquare className="w-4 h-4" />
                <h5 className="text-xs font-bold uppercase tracking-wider font-mono">Tasks Found</h5>
              </div>
              
              {deliverable.productivityInsights.tasksIdentified.length === 0 ? (
                <p className="text-[11px] text-slate-500 italic">No specific tasks extraction discovered.</p>
              ) : (
                <ul className="space-y-2">
                  {deliverable.productivityInsights.tasksIdentified.map((task, idx) => (
                    <li key={idx} className="flex items-start space-x-1.5 text-slate-300 text-xs">
                      <span className="text-indigo-400 font-bold shrink-0 mt-0.5">•</span>
                      <span className="leading-tight">{task}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* Column 2: Deadlines Found */}
            <div className="space-y-3">
              <div className="flex items-center space-x-1.5 text-purple-400">
                <Calendar className="w-4 h-4" />
                <h5 className="text-xs font-bold uppercase tracking-wider font-mono">Deadlines</h5>
              </div>

              {deliverable.productivityInsights.deadlinesFound.length === 0 ? (
                <p className="text-[11px] text-slate-500 italic">No schedules or dates found.</p>
              ) : (
                <ul className="space-y-2">
                  {deliverable.productivityInsights.deadlinesFound.map((deadline, idx) => (
                    <li key={idx} className="flex items-start space-x-1.5 text-slate-300 text-xs">
                      <span className="text-purple-400 font-bold shrink-0 mt-0.5">•</span>
                      <span className="leading-tight">{deadline}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* Column 3: Decisions Extracted */}
            <div className="space-y-3">
              <div className="flex items-center space-x-1.5 text-cyan-400">
                <Layers className="w-4 h-4" />
                <h5 className="text-xs font-bold uppercase tracking-wider font-mono">Decisions Made</h5>
              </div>

              {deliverable.productivityInsights.decisionsExtracted.length === 0 ? (
                <p className="text-[11px] text-slate-500 italic">No decisions extracted.</p>
              ) : (
                <ul className="space-y-2">
                  {deliverable.productivityInsights.decisionsExtracted.map((decision, idx) => (
                    <li key={idx} className="flex items-start space-x-1.5 text-slate-300 text-xs">
                      <span className="text-cyan-400 font-bold shrink-0 mt-0.5">•</span>
                      <span className="leading-tight">{decision}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
