import React, { useState } from "react";
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { auth, db } from "../lib/firebase";
import { doc, setDoc } from "firebase/firestore";
import { motion } from "motion/react";
import { Sparkles, AlertCircle, Loader2 } from "lucide-react";

interface AuthScreenProps {
  onAuthSuccess: (user: any) => void;
}

export default function AuthScreen({ onAuthSuccess }: AuthScreenProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);

    try {
      const provider = new GoogleAuthProvider();
      // Optional: Ask for consent if we want to ensure fresh login, but standard popup works best
      provider.setCustomParameters({
        prompt: "select_account"
      });

      const cred = await signInWithPopup(auth, provider);
      const user = cred.user;

      // Extract details
      const uid = user.uid;
      const name = user.displayName || "Google Workspace Member";
      const email = user.email || "";

      // Initialize or sync user document details in firestore
      const userDocRef = doc(db, "users", uid);
      await setDoc(userDocRef, {
        uid: uid,
        name: name,
        email: email,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      onAuthSuccess(user);
    } catch (err: any) {
      console.error("Google Authentication failed:", err);
      let message = "Failed to sign in with Google. Please retry the authentication flow.";
      if (err.code === "auth/popup-closed-by-user") {
        message = "The authentication popup was closed before completing. Please try again.";
      } else if (err.code === "auth/cancelled-popup-request") {
        message = "The authentication request was interrupted. Please retry.";
      } else if (err.code === "auth/operation-not-allowed") {
        message = "Google Sign-In is not enabled. Please enable Google Sign-In in your Firebase Auth providers console.";
      } else if (err.message) {
        message = err.message;
      }
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-center items-center relative overflow-hidden bg-[#020617] px-4 py-12">
      {/* Immersive Cosmic background visual grids & blur patterns */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[35rem] h-[35rem] rounded-full bg-cyan-500/10 blur-[130px] pointer-events-none -z-10 animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-[40rem] h-[40rem] rounded-full bg-indigo-500/10 blur-[150px] pointer-events-none -z-10"></div>
      
      {/* Fine-line technological grid overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_20%,#020617_90%)] bg-[linear-gradient(rgba(255,255,255,0.015)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none -z-10"></div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md space-y-8"
      >
        {/* Brand Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-cyan-400 p-[1.5px] shadow-[0_0_20px_rgba(99,102,241,0.35)]">
            <div className="flex h-full w-full items-center justify-center rounded-2xl bg-[#030712]">
              <Sparkles className="h-5 w-5 text-indigo-400 animate-pulse" />
            </div>
          </div>
          
          <div className="space-y-1">
            <h1 className="text-3xl font-bold tracking-tight text-white font-sans">
              Deliver<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-300">AI</span> Pro
            </h1>
            <p className="text-slate-400 text-xs tracking-wide uppercase font-semibold">AI Productivity Workspace</p>
          </div>
        </div>

        {/* Central Auth Container Card */}
        <div className="glass-panel p-8 rounded-2xl border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] bg-[#030712]/45 backdrop-blur-xl relative">
          <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent"></div>
          
          <div className="text-center space-y-2 mb-8">
            <h2 className="text-lg font-bold text-slate-100 tracking-tight">Access Your Workspace</h2>
            <p className="text-xs text-slate-400">Sign in securely with Google to sync your AI deliverables and templates.</p>
          </div>

          <div className="space-y-6">
            {error && (
              <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/25 text-red-400 text-xs flex flex-col space-y-2 animate-fade-in" id="auth-error-box">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed font-medium">
                    {error.includes("operation-not-allowed") || error.includes("OPERATION_NOT_ALLOWED")
                      ? "Google Authentication provider is disabled on this project."
                      : error}
                  </span>
                </div>
                {(error.includes("operation-not-allowed") || error.includes("OPERATION_NOT_ALLOWED")) && (
                  <div className="mt-2 bg-[#020617]/95 p-3.5 rounded-lg border border-indigo-500/20 space-y-2 text-slate-300 font-sans" id="auth-help-checklist">
                    <p className="font-bold text-indigo-400 text-[10px] uppercase tracking-wider">How to enable Google Sign-In:</p>
                    <ol className="list-decimal pl-4 space-y-1.5 text-[11px] leading-relaxed text-slate-400">
                      <li>
                        Open the{" "}
                        <a 
                          href="https://console.firebase.google.com/project/vast-totality-hf4nj/authentication/providers" 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-cyan-400 underline font-semibold hover:text-cyan-300 inline-flex items-center"
                        >
                          Firebase Console Providers Settings
                        </a>
                      </li>
                      <li>Click <strong className="text-slate-200">Add new provider</strong> and choose <strong className="text-slate-200">Google</strong>.</li>
                      <li>Enable Google provider, select project support email, and click <strong className="text-slate-200">Save</strong>.</li>
                    </ol>
                    <p className="text-[10px] text-slate-500 leading-normal pt-1.5 border-t border-white/5">
                      Once activated in the Firebase Console, you can close and re-trigger Google login.
                    </p>
                  </div>
                )}
              </div>
            )}

            <button
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full py-3 px-4 rounded-xl text-xs font-bold transition-all duration-300 flex items-center justify-center space-x-3 bg-white text-slate-900 hover:bg-slate-100 disabled:opacity-50 border border-slate-200 shadow-md transform active:scale-98 cursor-pointer"
              id="google-signin-btn"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                  <span className="text-slate-700 tracking-wider">CONNECTING SECURELY...</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      fill="#4285F4"
                    />
                    <path
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      fill="#34A853"
                    />
                    <path
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.62-.63-1.07-1.39-1.35-2.22"
                      fill="#FBBC05"
                    />
                    <path
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.82 2.94c.87-2.6 3.3-4.62 6.16-4.62z"
                      fill="#EA4335"
                    />
                  </svg>
                  <span className="font-sans font-semibold tracking-wide uppercase text-[11px]">Continue with Google</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Informative Footer */}
        <p className="text-slate-500 text-[10px] text-center max-w-sm mx-auto leading-normal">
          Secured by Google Firebase Web Cryptography. Every workspace session carries active multi-tenant encryption keys preventing client-side intercepts.
        </p>
      </motion.div>
    </div>
  );
}
