import { 
  LayoutDashboard, 
  Sparkles, 
  History, 
  BarChart3, 
  Settings,
  ArrowRightLeft,
  ChevronRight
} from "lucide-react";
import { ActiveTab } from "../types";

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  historyCount: number;
}

export default function Sidebar({ activeTab, setActiveTab, historyCount }: SidebarProps) {
  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "generate", label: "AI Generator", icon: Sparkles, badge: "AI Ready" },
    { id: "history", label: "History Panel", icon: History, count: historyCount },
    { id: "analytics", label: "Analytics Hub", icon: BarChart3 },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <aside className="glass-panel w-64 border-r border-white/10 flex flex-col min-h-[calc(100vh-80px)] shrink-0 shadow-2xl p-4">
      <nav className="space-y-1.5 flex-1" id="sidebar-nav">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as ActiveTab)}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-medium transition-all duration-300 group relative overflow-hidden ${
                isActive
                  ? "bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-transparent border border-indigo-500/35 text-white shadow-lg shadow-indigo-500/10"
                  : "text-slate-400 hover:text-white hover:bg-white/5 border border-transparent"
              }`}
              id={`sidebar-link-${item.id}`}
            >
              {/* Glow particle background for active states */}
              {isActive && (
                <div className="absolute -left-10 top-0 bottom-0 w-24 bg-gradient-to-r from-indigo-500/20 to-transparent blur-md"></div>
              )}

              <div className="flex items-center space-x-3 relative z-10">
                <Icon className={`w-4 h-4 transition-transform duration-300 group-hover:scale-110 ${
                  isActive ? "text-indigo-400 glow-indigo" : "text-slate-400 group-hover:text-indigo-300"
                }`} />
                <span className="font-sans font-medium">{item.label}</span>
              </div>

              {/* Badges/Count tags */}
              {item.badge && (
                <span className="relative z-10 text-[9px] px-2 py-0.5 rounded-md font-bold font-mono bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 uppercase leading-none scale-90">
                  {item.badge}
                </span>
              )}
              {item.count !== undefined && item.count > 0 && (
                <span className="relative z-10 text-xs px-2 py-0.5 rounded-full font-bold font-mono bg-slate-800 text-slate-300 border border-white/5 group-hover:border-indigo-500/10 group-hover:bg-indigo-950/40 transition-all">
                  {item.count}
                </span>
              )}

              {isActive && (
                <ChevronRight className="w-3.5 h-3.5 text-indigo-400 pointer-events-none" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Sidebar Footer Feature Card */}
      <div className="mt-auto pt-4 border-t border-white/10" id="sidebar-footer-card">
        <div className="relative p-4 rounded-xl overflow-hidden group bg-gradient-to-br from-indigo-950/30 to-purple-950/20 border border-white/5 shadow-inner">
          <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-indigo-500/10 to-transparent rounded-full blur-xl pointer-events-none"></div>
          
          <div className="relative z-10">
            <div className="flex items-center space-x-1 mb-1">
              <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping"></span>
              <p className="text-[10px] font-mono font-bold tracking-wider text-cyan-400 uppercase">SIGNATURE MODE</p>
            </div>
            <h4 className="text-xs font-semibold text-slate-100 font-display">Trio-Comparison</h4>
            <p className="text-[10px] text-slate-400 mt-1 leading-normal font-sans">
              Produce 3 deliverables (Professional, Executive, Academic) simultaneously in one search.
            </p>
            <button 
              onClick={() => setActiveTab("generate")}
              className="mt-3 w-full flex items-center justify-center space-x-2 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-white/5 text-slate-200 border border-white/10 hover:border-indigo-400 hover:text-white hover:bg-indigo-500/10 transition-all"
            >
              <span>Launch Engine</span>
              <Sparkles className="w-3 h-3 text-cyan-400" />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
