import { useState } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line, 
  Legend 
} from "recharts";
import { 
  Calculator, 
  TrendingUp, 
  ArrowRight, 
  Lightbulb, 
  CheckCircle2, 
  Sparkles,
  Award
} from "lucide-react";
import { motion } from "motion/react";

// Types for structural blocks
interface Token {
  type: "text" | "chart" | "flow" | "math" | "concept" | "revision" | "important";
  content: string;
  meta?: {
    chartType?: "bar" | "line" | "pie";
    title?: string;
  };
}

// Stateful parser that segments text content block by block (safer and easier than complex regexp)
export function parseSmartVisualNotes(text: string): Token[] {
  const lines = text.split("\n");
  const tokens: Token[] = [];
  
  let currentBlock: "text" | "chart" | "flow" | "math" | "concept" | "revision" | "important" | null = null;
  let currentLines: string[] = [];
  let currentMeta: any = {};
  
  for (let line of lines) {
    const trimmed = line.trim();
    
    // CHART trigger
    if (trimmed.startsWith("[CHART_START:")) {
      if (currentLines.length > 0) {
        tokens.push({ type: currentBlock || "text", content: currentLines.join("\n"), meta: currentMeta });
        currentLines = [];
      }
      
      const match = trimmed.match(/^\[CHART_START:(bar|line|pie):(.*?)\]$/i);
      currentBlock = "chart";
      currentMeta = {
        chartType: match ? match[1].toLowerCase() : "bar",
        title: match ? match[2] : "Data Visualization"
      };
    } else if (trimmed === "[CHART_END]") {
      tokens.push({ type: "chart", content: currentLines.join("\n"), meta: currentMeta });
      currentLines = [];
      currentBlock = null;
      currentMeta = {};
    } 
    // FLOW trigger
    else if (trimmed.startsWith("[FLOW_START:")) {
      if (currentLines.length > 0) {
        tokens.push({ type: currentBlock || "text", content: currentLines.join("\n"), meta: currentMeta });
        currentLines = [];
      }
      const match = trimmed.match(/^\[FLOW_START:(.*?)\]$/);
      currentBlock = "flow";
      currentMeta = {
        title: match ? match[1] : "Process Lifecycle"
      };
    } else if (trimmed === "[FLOW_END]") {
      tokens.push({ type: "flow", content: currentLines.join("\n"), meta: currentMeta });
      currentLines = [];
      currentBlock = null;
      currentMeta = {};
    } 
    // MATH trigger
    else if (trimmed === "[MATH_START]") {
      if (currentLines.length > 0) {
        tokens.push({ type: currentBlock || "text", content: currentLines.join("\n"), meta: currentMeta });
        currentLines = [];
      }
      currentBlock = "math";
      currentMeta = {};
    } else if (trimmed === "[MATH_END]") {
      tokens.push({ type: "math", content: currentLines.join("\n"), meta: currentMeta });
      currentLines = [];
      currentBlock = null;
      currentMeta = {};
    } 
    // CONCEPT trigger
    else if (trimmed.startsWith("[CONCEPT_START:")) {
      if (currentLines.length > 0) {
        tokens.push({ type: currentBlock || "text", content: currentLines.join("\n"), meta: currentMeta });
        currentLines = [];
      }
      const match = trimmed.match(/^\[CONCEPT_START:(.*?)\]$/);
      currentBlock = "concept";
      currentMeta = {
        title: match ? match[1] : "Core Concept Summary"
      };
    } else if (trimmed === "[CONCEPT_END]") {
      tokens.push({ type: "concept", content: currentLines.join("\n"), meta: currentMeta });
      currentLines = [];
      currentBlock = null;
      currentMeta = {};
    }
    // REVISION trigger
    else if (trimmed.startsWith("[REVISION_START:")) {
      if (currentLines.length > 0) {
        tokens.push({ type: currentBlock || "text", content: currentLines.join("\n"), meta: currentMeta });
        currentLines = [];
      }
      const match = trimmed.match(/^\[REVISION_START:(.*?)\]$/);
      currentBlock = "revision";
      currentMeta = {
        title: match ? match[1] : "Quick Revision Checklist"
      };
    } else if (trimmed === "[REVISION_END]") {
      tokens.push({ type: "revision", content: currentLines.join("\n"), meta: currentMeta });
      currentLines = [];
      currentBlock = null;
      currentMeta = {};
    }
    // IMPORTANT trigger
    else if (trimmed.startsWith("[IMPORTANT_START:")) {
      if (currentLines.length > 0) {
        tokens.push({ type: currentBlock || "text", content: currentLines.join("\n"), meta: currentMeta });
        currentLines = [];
      }
      const match = trimmed.match(/^\[IMPORTANT_START:(.*?)\]$/);
      currentBlock = "important";
      currentMeta = {
        title: match ? match[1] : "High-Yield Notes Card"
      };
    } else if (trimmed === "[IMPORTANT_END]" || trimmed === "[IMPORTANT_END]") {
      tokens.push({ type: "important", content: currentLines.join("\n"), meta: currentMeta });
      currentLines = [];
      currentBlock = null;
      currentMeta = {};
    }
    // General text buffer line
    else {
      currentLines.push(line);
    }
  }
  
  if (currentLines.length > 0) {
    tokens.push({ type: currentBlock || "text", content: currentLines.join("\n"), meta: currentMeta });
  }
  
  return tokens;
}

// -------------------------------------------------------------
// Component Renderers for Custom Blocks
// -------------------------------------------------------------

// 1. Math block beautifully formatted
export function MathEquationBlock({ content }: { content: string; key?: any }) {
  const equations = content.split("\n").map(l => l.trim()).filter(Boolean);

  const formatLatexToHtml = (eq: string) => {
    let output = eq;
    
    // Translate common Greek symbols
    const GreekSymbols: Record<string, string> = {
      "\\sigma": "σ",
      "\\alpha": "α",
      "\\beta": "β",
      "\\gamma": "γ",
      "\\theta": "θ",
      "\\lambda": "λ",
      "\\pi": "π",
      "\\mu": "μ",
      "\\delta": "δ",
      "\\Delta": "Δ",
      "\\Sigma": "Σ",
      "\\omega": "ω",
      "\\Omega": "Ω",
      "\\phi": "φ",
      "\\epsilon": "ε",
      "\\tau": "τ",
      "\\infinity": "∞",
      "\\inf": "∞",
      "\\infty": "∞",
      "\\approx": "≈",
      "\\neq": "≠",
      "\\bar{x}": "<span class='overline'>x</span>",
      "\\hat{y}": "<span class='underline'>ŷ</span>"
    };

    Object.entries(GreekSymbols).forEach(([latex, replace]) => {
      output = output.replaceAll(latex, replace);
    });

    // Translate common calculus notation (simplified visual structure)
    // Fractions e.g. \frac{numerator}{denominator}
    output = output.replace(/\\frac\{(.*?)\}\{(.*?)\}/g, (match, p1, p2) => {
      return `<span class="inline-flex flex-col align-middle text-center mx-1.5 leading-none">
        <span class="text-[12px] pb-[1px] border-b border-cyan-500/30 text-cyan-200 font-medium italic">${p1}</span>
        <span class="text-[11px] pt-[1.5px] text-slate-400 font-medium italic">${p2}</span>
      </span>`;
    });

    // Square root notation \sqrt{expression}
    output = output.replace(/\\sqrt\{(.*?)\}/g, `<span class="inline-flex items-center mx-1 font-serif text-slate-200">√<span class="border-t border-cyan-400/30 px-1 py-0.5 text-xs font-sans text-cyan-100">${1}</span></span>`);

    // Integral symbols \int_{a}^{b} or \int
    output = output.replace(/\\int_\{(.*?)\}\^\{(.*?)\}/g, `<span class="inline-flex flex-row align-middle items-center mr-1 text-[18px] text-indigo-400 font-sans italic relative">∫<sub class="text-[9px] text-slate-500 absolute -bottom-1 -left-[1px]">${1}</sub><sup class="text-[9px] text-cyan-300 absolute -top-1.5 -right-1">${2}</sup></span>`);
    
    // Summations \sum_{i=1}^{n}
    output = output.replace(/\\sum_\{(.*?)\}\^\{(.*?)\}/g, `<span class="inline-flex flex-row align-middle items-center mr-1 text-[16px] text-purple-400 font-sans relative">Σ<sub class="text-[8px] text-slate-500 absolute -bottom-1.5 -left-[1.5px]">${1}</sub><sup class="text-[8px] text-purple-300 absolute -top-1.5 -right-1">${2}</sup></span>`);

    // Basic superscripts x^2 or x^{y+z}
    output = output.replace(/\^\{(.*?)\}/g, `<sup class="text-[10px] text-cyan-300 italic ml-0.5">$1</sup>`);
    output = output.replace(/\^([a-zA-Z0-9])/g, `<sup class="text-[10px] text-cyan-300 italic ml-0.5">$1</sup>`);

    // Basic subscripts x_i or x_{i,j}
    output = output.replace(/_\{(.*?)\}/g, `<sub class="text-[9px] text-slate-500 ml-0.5">$1</sub>`);
    output = output.replace(/_([a-zA-Z0-9])/g, `<sub class="text-[9px] text-slate-500 ml-0.5">$1</sub>`);

    // Replace standard variables like single letter x, y, z, n, a, b with styled italic text
    // (making sure not to destroy html tag names)
    // Matches letters followed by space, operator or punctuation, or starting lines.
    
    return `<span class="font-serif select-all text-xs tracking-wide align-middle">${output}</span>`;
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="my-4 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/20 border border-indigo-500/20 rounded-xl p-4 flex flex-col space-y-3"
    >
      <div className="flex items-center justify-between border-b border-indigo-500/10 pb-2">
        <div className="flex items-center space-x-2 text-indigo-400">
          <Calculator className="w-4 h-4" />
          <span className="text-[11px] font-mono font-bold tracking-wider uppercase">Mathematical Equation</span>
        </div>
        <span className="text-[9px] font-mono text-slate-500 uppercase px-1.5 py-0.5 bg-slate-900 rounded select-none">LaTeX/Math Format</span>
      </div>

      <div className="space-y-2 py-1 text-center font-serif text-sm text-slate-200">
        {equations.map((eq, index) => (
          <div 
            key={index}
            className="p-2 py-3 bg-slate-950/40 rounded-lg border border-white/5 shadow-inner leading-relaxed overflow-x-auto select-all flex items-center justify-center min-h-[46px]"
            dangerouslySetInnerHTML={{ __html: formatLatexToHtml(eq) }}
          />
        ))}
      </div>
    </motion.div>
  );
}

// 2. Interactive Charts using Recharts
export function SmartChart({ 
  content, 
  type, 
  title 
}: { 
  content: string; 
  type: "bar" | "line" | "pie"; 
  title: string; 
  key?: any;
}) {
  const [activeItem, setActiveItem] = useState<{ name: string; value: number } | null>(null);

  // Parse key-value table pairs: Label: 120
  const parseDataGroup = () => {
    const rawLines = content.split("\n");
    const parsed: { name: string; value: number }[] = [];
    
    for (const l of rawLines) {
      const line = l.trim();
      if (!line) continue;
      const colonIndex = line.indexOf(":");
      if (colonIndex !== -1) {
        const rawName = line.substring(0, colonIndex).trim().replace(/^\*\s*|\*\s*$/g, "");
        const rawVal = line.substring(colonIndex + 1).trim();
        const value = parseFloat(rawVal);
        if (!isNaN(value)) {
          parsed.push({ name: rawName, value });
        }
      }
    }
    return parsed;
  };

  const data = parseDataGroup();

  if (data.length === 0) {
    return (
      <div className="p-3 bg-slate-900 border border-dashed border-white/10 text-xs text-slate-500 text-center rounded-xl">
        Empty or invalid numerical chart data
      </div>
    );
  }

  const customColors = [
    "#38BDF8", // cyan-400
    "#6366F1", // indigo-500
    "#A855F7", // purple-500
    "#E2E8F0", // slate-200
    "#F43F5E", // rose-500
    "#10B981", // emerald-500
    "#F59E0B"  // amber-500
  ];

  // Custom rich tooltips
  const CustomRechartTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-950 border border-indigo-500/20 shadow-2xl rounded-lg p-2.5 font-sans min-w-[124px]">
          <p className="text-[10px] text-slate-400 font-mono font-medium">{payload[0].name}</p>
          <div className="flex items-baseline space-x-1.5 mt-0.5">
            <span className="text-sm font-bold text-cyan-400">{payload[0].value.toLocaleString()}</span>
            <span className="text-[8px] text-slate-500 uppercase font-mono">units</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="my-5 bg-slate-900/60 rounded-xl border border-white/10 p-4 space-y-4 shadow-xl font-sans"
    >
      <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
        <div className="flex items-center space-x-2">
          <span className="p-1 rounded bg-cyan-950/50 text-cyan-400">
            <TrendingUp className="w-3.5 h-3.5" />
          </span>
          <h4 className="text-xs font-bold text-slate-200 tracking-tight font-sans">{title}</h4>
        </div>
        <span className="text-[9px] font-mono font-bold uppercase text-cyan-400 px-2 py-0.5 bg-cyan-950/40 border border-cyan-500/20 rounded">
          {type} chart
        </span>
      </div>

      <div className="h-[180px] w-full font-mono text-[9px] relative pr-2">
        <ResponsiveContainer width="100%" height="100%">
          {type === "bar" ? (
            <BarChart data={data} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" stroke="#64748b" tickSize={4} />
              <YAxis stroke="#64748b" />
              <Tooltip content={<CustomRechartTooltip />} />
              <Bar 
                dataKey="value" 
                radius={[4, 4, 0, 0]}
                onClick={(d: any) => setActiveItem(d)}
              >
                {data.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={customColors[index % customColors.length]} 
                    fillOpacity={activeItem?.name === entry.name ? 1 : 0.85}
                  />
                ))}
              </Bar>
            </BarChart>
          ) : type === "line" ? (
            <LineChart data={data} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="name" stroke="#64748b" />
              <YAxis stroke="#64748b" />
              <Tooltip content={<CustomRechartTooltip />} />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="#38bdf8" 
                strokeWidth={2.5} 
                dot={{ stroke: "#0f172a", strokeWidth: 1.5, r: 4, fill: "#818cf8" }}
                activeDot={{ r: 6 }} 
              />
            </LineChart>
          ) : (
            <PieChart>
              <Tooltip content={<CustomRechartTooltip />} />
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={35}
                outerRadius={65}
                paddingAngle={4}
                dataKey="value"
                onClick={(e: any, index: number) => setActiveItem(data[index])}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={customColors[index % customColors.length]} />
                ))}
              </Pie>
              <Legend verticalAlign="bottom" height={24} iconSize={8} iconType="circle" />
            </PieChart>
          )}
        </ResponsiveContainer>
      </div>

      {activeItem && (
        <div className="bg-slate-950/40 border border-white/5 rounded-lg p-2 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>Selected item: <strong className="text-slate-200">{activeItem.name}</strong></span>
          </div>
          <span className="font-mono text-cyan-300 font-bold">{activeItem.value.toLocaleString()} units</span>
        </div>
      )}
    </motion.div>
  );
}

// 3. Process Flowchart Timeline
export function ProcessFlowchart({ content, title }: { content: string; title: string; key?: any }) {
  // Parse format: Step X: Stage Name | Deep detail explanation
  const parseSteps = () => {
    const rawLines = content.split("\n");
    const steps: { label: string; details: string }[] = [];
    for (const line of rawLines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      
      const colonIdx = trimmed.indexOf(":");
      let remaining = trimmed;
      if (colonIdx !== -1 && trimmed.toLowerCase().startsWith("step")) {
        remaining = trimmed.substring(colonIdx + 1).trim();
      }
      
      const pipeIdx = remaining.indexOf("|");
      if (pipeIdx !== -1) {
        steps.push({
          label: remaining.substring(0, pipeIdx).trim(),
          details: remaining.substring(pipeIdx + 1).trim()
        });
      } else {
        steps.push({
          label: remaining,
          details: ""
        });
      }
    }
    return steps;
  };

  const steps = parseSteps();

  if (steps.length === 0) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      className="my-5 bg-gradient-to-br from-slate-900 to-slate-950/80 rounded-xl border border-white/10 p-5 space-y-4 shadow-xl"
    >
      <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
        <div className="flex items-center space-x-2 text-indigo-400">
          <CheckCircle2 className="w-4 h-4 text-indigo-400" />
          <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">{title}</h4>
        </div>
        <span className="text-[9px] font-mono text-slate-500 uppercase">{steps.length} Steps Sequence</span>
      </div>

      <div className="relative pl-6 border-l border-indigo-500/30 space-y-6 py-1 select-text">
        {steps.map((step, idx) => (
          <motion.div 
            key={idx} 
            className="group relative"
            whileHover={{ x: 2 }}
          >
            {/* Pulsing visual node locator */}
            <span className="absolute -left-[31px] top-1 flex items-center justify-center w-5 h-5 rounded-full bg-slate-950 border-2 border-indigo-500 text-[10px] font-mono font-bold text-indigo-300 shadow-[0_0_8px_rgba(99,102,241,0.4)] group-hover:scale-110 transition-transform">
              {idx + 1}
            </span>

            {/* Content card */}
            <div className="p-3 bg-white/5 rounded-lg border border-white/5 group-hover:border-indigo-500/20 group-hover:bg-indigo-950/10 transition-all">
              <h5 className="text-xs font-bold text-white group-hover:text-indigo-300 transition-colors">
                {step.label}
              </h5>
              {step.details && (
                <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                  {step.details}
                </p>
              )}
            </div>

            {/* Pointing vertical flow connector marker */}
            {idx < steps.length - 1 && (
              <div className="absolute -left-[27px] bottom-[-22px] text-indigo-500/40 select-none">
                <ArrowRight className="w-3 h-3 rotate-90" />
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

// 4. Conceptual Bento box Visual Summary
export function ConceptBentoGrid({ content, title }: { content: string; title: string; key?: any }) {
  // Parse format: Badge | Title | Deep descriptive detail
  const parseConcepts = () => {
    const rawLines = content.split("\n");
    const data: { badge: string; name: string; desc: string }[] = [];
    for (const line of rawLines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      const parts = trimmed.split("|");
      if (parts.length >= 3) {
        data.push({
          badge: parts[0].trim(),
          name: parts[1].trim(),
          desc: parts.slice(2).join("|").trim()
        });
      } else if (parts.length === 2) {
        data.push({
          badge: "Concept",
          name: parts[0].trim(),
          desc: parts[1].trim()
        });
      }
    }
    return data;
  };

  const items = parseConcepts();

  if (items.length === 0) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="my-5 space-y-4"
    >
      <div className="flex items-center justify-between border-b border-white/5 pb-2">
        <div className="flex items-center space-x-2 text-purple-400 font-mono">
          <Lightbulb className="w-4 h-4 text-purple-400" />
          <h4 className="text-xs font-bold text-slate-200 tracking-wider uppercase">{title}</h4>
        </div>
        <span className="text-[9px] font-mono text-slate-500 uppercase px-1 py-0.5 bg-slate-900 rounded">Bento Grid Summary</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {items.map((item, idx) => (
          <div 
            key={idx}
            className="relative overflow-hidden bg-gradient-to-br from-slate-900 to-indigo-950/20 border border-white/5 hover:border-purple-500/20 p-4 rounded-xl shadow-md transition-all group hover:shadow-purple-950/10"
          >
            {/* Subtle background abstract circle decor */}
            <span className="absolute -right-2 -bottom-2 w-14 h-14 bg-purple-500/5 rounded-full blur-xl group-hover:scale-150 transition-transform" />

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[9px] select-none font-mono font-bold tracking-wider uppercase text-purple-300 px-1.5 py-0.5 bg-purple-400/10 rounded-md border border-purple-400/20">
                  {item.badge}
                </span>
                <Sparkles className="w-3 h-3 text-purple-500/35 group-hover:text-purple-400 transition-colors" />
              </div>
              <h5 className="text-xs font-bold text-white tracking-tight group-hover:text-purple-300 transition-colors">
                {item.name}
              </h5>
              <p className="text-[11px] text-slate-400 leading-normal font-normal">
                {item.desc}
              </p>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

// 5. Quick Revision & Memorization checklist recall box
export function QuickRevisionRecap({ content, title }: { content: string; title: string; key?: any }) {
  const parseLines = () => {
    return content.split("\n").map(l => l.trim()).filter(Boolean);
  };
  const items = parseLines();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="my-5 border border-emerald-500/20 bg-emerald-950/10 p-5 rounded-xl shadow-md space-y-3"
    >
      <div className="flex items-center space-x-2 text-emerald-400 font-mono">
        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
        <h4 className="text-xs font-bold text-emerald-300 tracking-wider uppercase">{title}</h4>
      </div>
      <ul className="space-y-2">
        {items.map((item, idx) => {
          const clean = item.replace(/^\*\s*|-\s*/, "").replace(/\*\*(.*?)\*\*/g, "$1");
          return (
            <li key={idx} className="flex items-start text-sm text-slate-300 gap-2 font-normal leading-relaxed">
              <span className="text-emerald-400 select-none font-bold">✓</span>
              <span>{clean}</span>
            </li>
          );
        })}
      </ul>
    </motion.div>
  );
}

// 6. High-Yield Important Points Card
export function ImportantBriefCard({ content, title }: { content: string; title: string; key?: any }) {
  const parseLines = () => {
    return content.split("\n").map(l => l.trim()).filter(Boolean);
  };
  const items = parseLines();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="my-5 flex border-l-4 border-amber-500 bg-amber-950/10 rounded-r-xl p-5 shadow-md"
    >
      <div className="space-y-2.5 w-full">
        <div className="flex items-center space-x-2 text-amber-400 font-mono">
          <Lightbulb className="w-5 h-5 text-amber-400 shrink-0" />
          <h4 className="text-xs font-bold text-amber-300 tracking-wider uppercase">{title}</h4>
        </div>
        <div className="space-y-2">
          {items.map((item, idx) => {
            const clean = item.replace(/^\*\s*|-\s*/, "").replace(/\*\*(.*?)\*\*/g, "$1");
            return (
              <p key={idx} className="text-sm text-amber-200/90 leading-relaxed pl-3.5 relative before:content-['•'] before:absolute before:left-0 before:text-amber-500 font-normal">
                {clean}
              </p>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}

// Custom Markdown rendering core parsed with robust, standard regex compiling
export function StandaloneMarkdownRenderer({ text }: { text: string; key?: any }) {
  const parseMarkdown = (md: string) => {
    // Process markdown structures
    let html = md
      .replace(/^### (.*$)/gim, '<h4 class="text-sm font-bold text-teal-300 tracking-wider uppercase mt-5 mb-2.5">$1</h4>')
      .replace(/^## (.*$)/gim, '<h3 class="text-base font-bold text-indigo-100/90 tracking-tight border-b border-white/10 pb-1.5 mt-6 mb-3">$1</h3>')
      .replace(/^# (.*$)/gim, '<h2 class="text-lg font-bold text-cyan-300 font-display mt-7 mb-4">$1</h2>');

    // Bold formatting
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-white bg-indigo-500/15 px-1.5 py-0.5 rounded">$1</strong>');

    // Bullet line formatting
    html = html.replace(/^\* (.*$)/gim, '<li class="ml-4 list-disc text-slate-300 text-sm py-1 leading-relaxed">$1</li>');
    html = html.replace(/^- (.*$)/gim, '<li class="ml-4 list-disc text-slate-300 text-sm py-1 leading-relaxed">$1</li>');

    const lines = html.split("\n");
    const formattedLines = lines.map((line) => {
      if (line.trim().startsWith("<h") || line.trim().startsWith("<li") || line.trim() === "") {
        return line;
      }
      return `<p class="text-sm text-slate-300 font-normal leading-relaxed mt-2">${line}</p>`;
    });

    return formattedLines.join("\n");
  };

  return (
    <div 
      className="space-y-1 select-text"
      dangerouslySetInnerHTML={{ __html: parseMarkdown(text) }}
    />
  );
}

// -------------------------------------------------------------
// MAIN COMPONENT EXPORT
// -------------------------------------------------------------
export default function SmartMarkdownRenderer({ text }: { text: string }) {
  if (!text) return null;

  // Segment our master document text into various interactive component visual tokens
  const tokens = parseSmartVisualNotes(text);

  return (
    <div className="space-y-3 font-sans select-text">
      {tokens.map((token, index) => {
        switch (token.type) {
          case "math":
            return <MathEquationBlock key={index} content={token.content} />;
            
          case "chart":
            return (
              <SmartChart 
                key={index} 
                content={token.content} 
                type={token.meta?.chartType || "bar"} 
                title={token.meta?.title || "Data Insight"} 
              />
            );
            
          case "flow":
            return (
              <ProcessFlowchart 
                key={index} 
                content={token.content} 
                title={token.meta?.title || "System workflow"} 
              />
            );
            
          case "concept":
            return (
              <ConceptBentoGrid 
                key={index} 
                content={token.content} 
                title={token.meta?.title || "Concept block"} 
              />
            );
            
          case "revision":
            return (
              <QuickRevisionRecap 
                key={index} 
                content={token.content} 
                title={token.meta?.title || "Quick Revision Checklist"} 
              />
            );
            
          case "important":
            return (
              <ImportantBriefCard 
                key={index} 
                content={token.content} 
                title={token.meta?.title || "High-Yield Notes Card"} 
              />
            );
            
          case "text":
          default:
            return <StandaloneMarkdownRenderer key={index} text={token.content} />;
        }
      })}
    </div>
  );
}
