import { 
  BarChart3, 
  TrendingUp, 
  Clock, 
  FileCheck2, 
  Flame, 
  Activity, 
  UserCheck,
  CheckCircle,
  Award
} from "lucide-react";
import { Deliverable } from "../types";

interface AnalyticsPanelProps {
  deliverables: Deliverable[];
}

export default function AnalyticsPanel({ deliverables }: AnalyticsPanelProps) {
  const totalCount = deliverables.length;
  const totalTimeSavedMinutes = deliverables.reduce((acc, curr) => acc + (curr.productivityInsights?.estimatedTimeSavedMinutes || 0), 0);
  const totalHoursSaved = (totalTimeSavedMinutes / 60).toFixed(1);

  // Quality Stats
  const avgReadability = totalCount > 0 
    ? Math.round(deliverables.reduce((acc, curr) => acc + curr.qualityScores.readability, 0) / totalCount)
    : 0;
  const avgProfessionalism = totalCount > 0 
    ? Math.round(deliverables.reduce((acc, curr) => acc + curr.qualityScores.professionalism, 0) / totalCount)
    : 0;
  const avgCompleteness = totalCount > 0 
    ? Math.round(deliverables.reduce((acc, curr) => acc + curr.qualityScores.completeness, 0) / totalCount)
    : 0;
  const avgClarity = totalCount > 0 
    ? Math.round(deliverables.reduce((acc, curr) => acc + curr.qualityScores.clarity, 0) / totalCount)
    : 0;

  const averageQualityIndex = totalCount > 0
    ? Math.round((avgReadability + avgProfessionalism + avgCompleteness + avgClarity) / 4)
    : 0;

  // Deliverable types frequency count
  const counts = { report: 0, email: 0, meeting_minutes: 0, study_notes: 0 };
  deliverables.forEach((item) => {
    if (counts[item.deliverableType] !== undefined) {
      counts[item.deliverableType]++;
    }
  });

  const totalTypes = Math.max(1, counts.report + counts.email + counts.meeting_minutes + counts.study_notes);
  const frequencies = [
    { label: "Professional Report", rawValue: counts.report, percentage: Math.round((counts.report / totalTypes) * 100), color: "bg-indigo-500", border: "border-indigo-500/20" },
    { label: "Professional Email", rawValue: counts.email, percentage: Math.round((counts.email / totalTypes) * 100), color: "bg-purple-500", border: "border-purple-500/20" },
    { label: "Meeting Minutes", rawValue: counts.meeting_minutes, percentage: Math.round((counts.meeting_minutes / totalTypes) * 100), color: "bg-cyan-500", border: "border-cyan-500/20" },
    { label: "Study Notes", rawValue: counts.study_notes, percentage: Math.round((counts.study_notes / totalTypes) * 100), color: "bg-emerald-500", border: "border-emerald-500/20" },
  ].sort((a,b) => b.rawValue - a.rawValue);

  // Weekly Activity Chart calculations (simulated days from seed timestamps + current date)
  // Let's map active documents into day of week (0=Sun, 1=Mon, etc.)
  const weekDaysShort = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const dailyCounts = [0, 0, 0, 0, 0, 0, 0]; // Sun to Sat
  
  deliverables.forEach((item) => {
    const d = new Date(item.createdAt);
    const day = d.getDay();
    dailyCounts[day] += 1;
  });

  const maxDayCount = Math.max(1, ...dailyCounts);

  return (
    <div className="space-y-8 animate-fade-in" id="analytics-panel">
      {/* Title Header */}
      <div className="border-b border-white/10 pb-4">
        <h3 className="text-xl font-bold font-display text-white">System Analytics</h3>
        <p className="text-slate-400 text-xs mt-0.5">Full intelligence index report detailing your saved energy, processing count, and accuracy indexes.</p>
      </div>

      {/* Hero statistics grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="analytics-mini-grid">
        <div className="glass-panel p-5 rounded-2xl border border-white/5 flex items-center space-x-4">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 rounded-xl">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold text-white font-mono">{totalHoursSaved}h</p>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-semibold">Total Hours Saved</p>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/5 flex items-center space-x-4">
          <div className="p-3 bg-purple-500/10 border border-purple-500/30 text-purple-400 rounded-xl">
            <FileCheck2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold text-white font-mono">{totalCount}</p>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-semibold">Deliverables Indexed</p>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/5 flex items-center space-x-4">
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded-xl">
            <Award className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <p className="text-2xl font-bold text-white font-mono">{averageQualityIndex}%</p>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-semibold">Avg Quality Index</p>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-white/5 flex items-center space-x-4">
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <p className="text-2xl font-bold text-white font-mono">{totalCount > 0 ? "Daily Active" : "Paused"}</p>
            <p className="text-[11px] text-slate-500 uppercase tracking-wider font-semibold">Workspace Status</p>
          </div>
        </div>
      </section>

      {/* Main Analysis Chart Area (Weekly + Frequencies) */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Weekly Productivity Heatmap / Bar chart (2 Columns) */}
        <div className="lg:col-span-2 glass-panel p-6 rounded-2xl border border-white/5 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4 text-cyan-400 animate-pulse" />
              <h4 className="text-sm font-bold text-white font-display">Weekly Activity Cycle</h4>
            </div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-white/5 text-slate-450 px-2 py-0.5 rounded leading-none">
              Generated Records Map
            </span>
          </div>

          {/* SVG Responsive Bar Chart layout */}
          <div className="h-56 w-full flex flex-col justify-between" id="weekly-vector-bars-chart">
            <div className="flex-1 flex items-end justify-between px-4 pb-4 border-b border-white/10 relative">
              {/* Background grid lines */}
              <div className="absolute inset-0 flex flex-col justify-between py-2 pointer-events-none -z-10 opacity-30">
                <div className="border-t border-dashed border-white/5 w-full"></div>
                <div className="border-t border-dashed border-white/5 w-full"></div>
                <div className="border-t border-dashed border-white/5 w-full"></div>
              </div>

              {dailyCounts.map((count, idx) => {
                const heightPercentage = Math.round((count / maxDayCount) * 100);
                const showHeight = count === 0 ? "6px" : `${heightPercentage}%`;
                
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center group relative mt-2">
                    {/* Hover Tooltip widget showing count tags */}
                    <span className="absolute -top-7 text-[10px] font-mono font-bold bg-[#030014] border border-white/10 text-cyan-400 px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-all z-20 pointer-events-none">
                      {count} items
                    </span>

                    {/* Gradient Bar item */}
                    <div 
                      className={`w-10 rounded-t-lg bg-gradient-to-t transition-all duration-500 shadow-[0_0_12px_rgba(99,102,241,0.15)] group-hover:shadow-[0_0_18px_rgba(99,102,241,0.35)] cursor-pointer ${
                        count === 0 
                          ? "from-slate-900 to-slate-800" 
                          : "from-indigo-600 via-purple-500 to-cyan-400"
                      }`}
                      style={{ height: showHeight }}
                    ></div>
                  </div>
                );
              })}
            </div>

            {/* Labels under Bars */}
            <div className="flex justify-between px-4 pt-2 text-[10px] font-mono text-slate-500">
              {weekDaysShort.map((day, i) => (
                <span key={i} className="w-10 text-center font-bold tracking-wider uppercase">{day}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Deliverable types frequency count breakdown (1 Column) */}
        <div className="glass-panel p-6 rounded-2xl border border-white/5 space-y-6">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-purple-400" />
            <h4 className="text-sm font-bold text-white font-display">Format Deliverable Types</h4>
          </div>

          <div className="space-y-4" id="deliverable-types-breakdown">
            {frequencies.map((freq, i) => (
              <div key={i} className="space-y-1.5 p-3 rounded-xl bg-white/5 border border-white/5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-305">{freq.label}</span>
                  <span className="font-mono font-bold text-slate-100">{freq.rawValue} doc ({freq.percentage}%)</span>
                </div>
                {/* Visual horizontal loading bar */}
                <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${freq.color} rounded-full transition-all duration-500`}
                    style={{ width: `${freq.rawValue === 0 ? 0 : freq.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bento Grid layout for quality breakdowns */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" id="quality-bento-section">
        {[
          { metric: "Readability Score", score: avgReadability, highlight: "Text Rhythm & Length", color: "text-indigo-400", bg: "bg-indigo-500/10" },
          { metric: "Professionalism", score: avgProfessionalism, highlight: "Terminology Density", color: "text-purple-400", bg: "bg-purple-500/10" },
          { metric: "Completeness Check", score: avgCompleteness, highlight: "No Information Lost", color: "text-cyan-400", bg: "bg-cyan-500/10" },
          { metric: "Clarity Rating", score: avgClarity, highlight: "Grammar & Flow", color: "text-emerald-400", bg: "bg-emerald-500/10" },
        ].map((item, idx) => (
          <div key={idx} className="glass-panel p-5 rounded-2xl border border-white/5 space-y-3 hover:border-indigo-500/20 transition-all duration-300">
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider font-mono">{item.metric}</p>
            <div className="flex items-baseline space-x-2">
              <span className={`text-4xl font-extrabold font-display ${item.color}`}>{item.score}%</span>
              <span className="text-[10px] text-slate-450 font-mono">Index Score</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-normal">{item.highlight}</p>
          </div>
        ))}
      </section>

    </div>
  );
}
