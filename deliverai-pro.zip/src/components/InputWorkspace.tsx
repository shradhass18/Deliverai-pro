import { useState, useRef, DragEvent, ChangeEvent, useEffect } from "react";
import { 
  Sparkles, 
  FileText, 
  Mail, 
  Users, 
  BookOpen, 
  Upload, 
  File, 
  X, 
  AudioLines,
  Volume2,
  CheckCircle,
  HelpCircle,
  Mic,
  Square,
  Trash2,
  Play,
  Pause,
  RefreshCw
} from "lucide-react";
import { Deliverable } from "../types";

interface InputWorkspaceProps {
  onGenerate: (inputText: string, deliverableType: string, tone: string, file: any) => void;
  isGenerating: boolean;
  activeGenerationStep: string; // "idle" | "upload" | "transcribing" | "gemini" | "structuring"
}

export default function InputWorkspace({ onGenerate, isGenerating, activeGenerationStep }: InputWorkspaceProps) {
  const [inputText, setInputText] = useState("");
  const [selectedType, setSelectedType] = useState<"report" | "email" | "meeting_minutes" | "study_notes">("report");
  const [selectedTone, setSelectedTone] = useState<string>("professional");
  const [attachedFile, setAttachedFile] = useState<{ name: string; type: string; size: number; data: string } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  // Voice Recording Workspace States
  const [activeInputTab, setActiveInputTab] = useState<"file" | "voice">("file");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [microphoneError, setMicrophoneError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const audioPlayerRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const startVoiceRecording = async () => {
    setMicrophoneError(null);
    setAudioUrl(null);
    audioChunksRef.current = [];
    setRecordingDuration(0);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const options = { mimeType: MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "" };
      const recorder = new MediaRecorder(stream, options);
      
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: options.mimeType || "audio/wav" });
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);

        // Convert blob to base64 so it can stream server-side to Gemini multimodal models
        const fileReader = new FileReader();
        fileReader.onload = () => {
          if (fileReader.result) {
            setAttachedFile({
              name: `voice_recording_${new Date().toISOString().replace(/[:.]/g, "-")}.webm`,
              type: audioBlob.type || "audio/webm",
              size: audioBlob.size,
              data: fileReader.result as string
            });
          }
        };
        fileReader.readAsDataURL(audioBlob);

        // Stop all media tracks to free the mic
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorderRef.current = recorder;
      recorder.start(1000); // chunk every 1 sec
      setIsRecording(true);

      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);

    } catch (err: any) {
      console.error("Microphone access error:", err);
      setMicrophoneError("Could not access your microphone. Please check permissions.");
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const discardVoiceRecording = () => {
    stopVoiceRecording();
    setAudioUrl(null);
    setAttachedFile(null);
    setRecordingDuration(0);
    audioChunksRef.current = [];
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const deliverableTypes = [
    { id: "report", label: "Professional Report", icon: FileText, desc: "Detailed, business-oriented analytical layout" },
    { id: "email", label: "Professional Email", icon: Mail, desc: "Polished, clear, and direct outreach letters" },
    { id: "meeting_minutes", label: "Meeting Minutes", icon: Users, desc: "Structured logs with tasks, milestones, and deadlines" },
    { id: "study_notes", label: "Study Notes", icon: BookOpen, desc: "Educational briefings defining key concepts" }
  ];

  const tones = [
    { id: "professional", label: "Professional", color: "from-indigo-500 to-indigo-400" },
    { id: "executive", label: "Executive", color: "from-purple-500 to-purple-400" },
    { id: "academic", label: "Academic", color: "from-emerald-500 to-emerald-400" },
    { id: "corporate", label: "Corporate", color: "from-blue-500 to-blue-400" },
    { id: "friendly", label: "Friendly", color: "from-pink-500 to-pink-400" },
    { id: "formal", label: "Formal", color: "from-cyan-500 to-cyan-400" }
  ];

  // Drag and drop events
  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const processFile = (file: File) => {
    const reader = new FileReader();

    // Check if txt or other readable textual files
    if (file.type === "text/plain" || file.name.endsWith(".txt") || file.name.endsWith(".md")) {
      reader.onload = (e) => {
        if (e.target?.result) {
          setInputText((prev) => prev ? `${prev}\n\n---\nFile Content (${file.name}):\n${e.target!.result}` : e.target!.result as string);
        }
      };
      reader.readAsText(file);
    } else {
      // Load standard files (like maps, PDFs, or MP3s) into base64 for direct streaming to Gemini
      reader.onload = (e) => {
        if (e.target?.result) {
          setAttachedFile({
            name: file.name,
            type: file.type || "application/octet-stream",
            size: file.size,
            data: e.target.result as string
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const removeAttachment = () => {
    setAttachedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = () => {
    if (!inputText.trim() && !attachedFile) return;
    onGenerate(inputText, selectedType, selectedTone, attachedFile);
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const isAudioFile = attachedFile?.type.startsWith("audio/");

  return (
    <div className="space-y-8 animate-fade-in" id="input-workspace">
      {/* Title Header */}
      <div>
        <h3 className="text-2xl font-bold font-display text-white">Generate Deliverable</h3>
        <p className="text-slate-400 text-sm mt-1">Provide your source notes or upload files to configure your output.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Side: Content entry and Drag Upload (2 columns) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main prompt input box */}
          <div className="glass-panel rounded-2xl p-5 border border-white/5 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-slate-300">Unstructured Source Content</label>
              <span className="text-[10px] font-mono text-slate-500">{inputText.length} characters</span>
            </div>
            
            <textarea
              placeholder="Paste raw notes, rough structures, ideas, lists, transcripts, or drafts here..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full h-64 bg-slate-950/40 text-slate-200 p-4 text-sm rounded-xl border border-white/5 outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/30 transition-all placeholder:text-slate-600 resize-none font-sans"
              disabled={isGenerating}
              id="raw-content-textarea"
            />
          </div>

          {/* Choice selector buttons for File Upload vs Real-time Voice Memo */}
          <div className="flex items-center space-x-2 bg-slate-950/60 p-1.5 rounded-2xl border border-white/5 shadow-inner">
            <button
              type="button"
              onClick={() => setActiveInputTab("file")}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                activeInputTab === "file"
                  ? "bg-indigo-650/95 text-white border border-indigo-500/30 shadow-[0_4px_12px_rgba(99,102,241,0.25)]"
                  : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.01]"
              }`}
            >
              <Upload className="w-4 h-4 shrink-0" />
              <span>📂 File Attachment</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveInputTab("voice")}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                activeInputTab === "voice"
                  ? "bg-indigo-650/95 text-white border border-indigo-500/30 shadow-[0_4px_12px_rgba(99,102,241,0.25)] animate-pulse-subtle"
                  : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.01]"
              }`}
            >
              <Mic className="w-4 h-4 shrink-0" />
              <span>🎙️ Live Voice Recorder</span>
            </button>
          </div>

          {activeInputTab === "file" ? (
            /* Premium Drag and drop area */
            <div 
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`glass-panel border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-350 ${
                isDragging 
                  ? "border-cyan-400/60 bg-cyan-950/15" 
                  : attachedFile 
                    ? "border-emerald-500/30 bg-emerald-950/5" 
                    : "border-white/10 hover:border-indigo-500/30 hover:bg-white/[0.02]"
              }`}
              id="drag-drop-zone"
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept=".txt,.md,.pdf,audio/*"
              />
              
              {attachedFile ? (
                <div className="flex flex-col items-center space-y-3" onClick={(e) => e.stopPropagation()}>
                  <div className={`p-4 rounded-full ${isAudioFile ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 animate-pulse' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'}`}>
                    {isAudioFile ? <AudioLines className="w-8 h-8" /> : <File className="w-8 h-8" />}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-100 font-display">{attachedFile.name}</p>
                    <p className="text-xs text-slate-400 font-mono mt-1">
                      {formatSize(attachedFile.size)} • {attachedFile.type || "Attached document"}
                    </p>
                  </div>
                  {isAudioFile && (
                    <div className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/35 text-cyan-400 text-[10px] font-mono font-bold uppercase">
                      <Volume2 className="w-3.5 h-3.5 animate-bounce" />
                      <span>Voice to text enabled</span>
                    </div>
                  )}
                  <button
                    onClick={removeAttachment}
                    className="flex items-center space-x-1.5 py-1.5 px-3 rounded-lg text-xs bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500 hover:text-white transition-all mt-2"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Remove File</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-4 font-sans">
                  <div className="mx-auto flex items-center justify-center w-12 h-12 bg-indigo-500/10 text-indigo-400 rounded-full border border-indigo-500/20 group-hover:scale-105 transition-transform duration-300">
                    <Upload className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-250">Drag & Drop Documents or Audio files here</p>
                    <p className="text-[11px] text-slate-500 mt-1">Supports TXT, MD, PDF (documents) & WAV, MP3, M4A, OGG (audio) up to 25MB</p>
                  </div>
                  <button type="button" className="py-2.5 px-4 rounded-xl text-xs bg-white/5 border border-white/10 hover:border-indigo-400 text-slate-300 hover:text-white font-medium transition-all">
                    Browse Files
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Voice recording interface */
            <div className="glass-panel border-2 border-dashed rounded-2xl p-6 bg-slate-950/30 relative overflow-hidden flex flex-col items-center justify-center min-h-[220px] transition-all duration-300 border-white/10">
              {microphoneError && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 text-red-400 text-xs text-center mb-4 max-w-sm">
                  {microphoneError}
                </div>
              )}

              {isRecording ? (
                <div className="flex flex-col items-center space-y-4 py-3 w-full">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 rounded-full bg-red-500 animate-ping"></div>
                    <span className="text-xs font-bold tracking-wide text-red-400 font-mono">RECORDING LIVE AUDIO</span>
                    <span className="text-2xl font-bold font-mono text-white tracking-widest">{formatDuration(recordingDuration)}</span>
                  </div>

                  {/* Mechanical high quality responsive feedback waves */}
                  <div className="flex items-end justify-center space-x-1.5 h-12 w-64">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20].map((bar) => {
                      const heights = ["h-3", "h-6", "h-10", "h-8", "h-11", "h-5", "h-10", "h-7", "h-11", "h-6", "h-9", "h-4", "h-8", "h-6", "h-3", "h-6", "h-9", "h-4", "h-7", "h-3"];
                      const delay = bar * 80;
                      return (
                        <div
                          key={bar}
                          style={{ animationDelay: `${delay}ms` }}
                          className={`w-1 rounded-full bg-gradient-to-t from-indigo-500 to-cyan-400 animate-wave ${heights[bar - 1]}`}
                        ></div>
                      );
                    })}
                  </div>

                  <p className="text-[11px] text-slate-400 font-medium">Capture your meeting, instructions or notes via mic stream</p>

                  <div className="flex items-center space-x-3.5">
                    <button
                      type="button"
                      onClick={stopVoiceRecording}
                      className="flex items-center space-x-2 py-2 px-5 rounded-full text-xs font-bold bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-650 text-white border border-red-500/10 shadow-lg shadow-red-500/15 transition-all cursor-pointer"
                    >
                      <Square className="w-3.5 h-3.5 fill-white shrink-0" />
                      <span>Stop & Attach</span>
                    </button>
                    <button
                      type="button"
                      onClick={discardVoiceRecording}
                      className="flex items-center space-x-1.5 py-2 px-4 rounded-full text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-400 hover:text-slate-200 border border-white/5 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5 shrink-0" />
                      <span>Cancel</span>
                    </button>
                  </div>
                </div>
              ) : attachedFile && attachedFile.name.startsWith("voice_recording_") ? (
                <div className="flex flex-col items-center space-y-4 py-2 w-full max-w-sm">
                  <div className="text-center space-y-1 bg-emerald-500/10 border border-emerald-500/25 px-4 py-1.5 rounded-full">
                    <p className="text-xs font-bold text-emerald-400 flex items-center space-x-1.5">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Voice Memo Captured & Embedded</span>
                    </p>
                  </div>

                  {/* Playback standard preview controls */}
                  <div className="w-full bg-slate-900/40 rounded-xl p-3 border border-white/5 flex flex-col space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-slate-400 truncate max-w-[200px]">{attachedFile.name}</span>
                      <span className="text-[10px] font-mono text-slate-500">{formatSize(attachedFile.size)}</span>
                    </div>
                    {audioUrl && (
                      <audio 
                        ref={audioPlayerRef}
                        src={audioUrl} 
                        controls 
                        className="w-full h-8 outline-none text-xs bg-slate-950/60 rounded-md" 
                      />
                    )}
                  </div>

                  <div className="flex items-center space-x-3">
                    <button
                      type="button"
                      onClick={startVoiceRecording}
                      className="flex items-center space-x-1.5 py-1.5 px-3.5 rounded-full text-xs font-semibold bg-white/5 hover:bg-white/10 text-indigo-400 hover:text-indigo-300 border border-indigo-500/20 transition-all cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5 shrink-0" />
                      <span>Record Again</span>
                    </button>
                    <button
                      type="button"
                      onClick={discardVoiceRecording}
                      className="flex items-center space-x-1.5 py-1.5 px-3.5 rounded-full text-xs font-semibold bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/10 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5 shrink-0" />
                      <span>Delete Memo</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center space-y-4 py-3 text-center">
                  <div className="w-14 h-14 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shadow-[0_0_20px_rgba(99,102,241,0.06)]">
                    <Mic className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-100">Record Live Voice Memo</h4>
                    <p className="text-xs text-slate-500 max-w-[340px] mt-1 leading-relaxed">
                      Speak your thoughts or record an active conversation. We'll automatically transcribe it and construct detailed deliverables via our agentic pipeline.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={startVoiceRecording}
                    className="py-2.5 px-6 rounded-xl text-xs bg-indigo-650 hover:bg-indigo-600 text-white font-bold transition-all shadow-md shadow-indigo-600/15 cursor-pointer uppercase tracking-wider"
                  >
                    Start Mic Stream
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Side: Configuration (Deliverable specifications) (1 column) */}
        <div className="space-y-6">
          {/* Deliverable Type Selectors */}
          <div className="glass-panel rounded-2xl p-5 border border-white/5 space-y-4">
            <label className="text-sm font-semibold text-slate-300">1. Target Deliverable Type</label>
            <div className="grid grid-cols-1 gap-2.5" id="type-cards-grid">
              {deliverableTypes.map((type) => {
                const Icon = type.icon;
                const isSelected = selectedType === type.id;
                return (
                  <div
                    key={type.id}
                    onClick={() => !isGenerating && setSelectedType(type.id as any)}
                    className={`flex items-start space-x-3.5 p-3.5 rounded-xl border cursor-pointer transition-all duration-300 ${
                      isSelected 
                        ? "bg-indigo-950/30 border-indigo-500/50 shadow-lg shadow-indigo-500/5" 
                        : "border-white/5 hover:border-white/10 hover:bg-white/[0.01]"
                    }`}
                    id={`type-card-${type.id}`}
                  >
                    <div className={`p-2.5 rounded-lg border shrink-0 ${
                      isSelected 
                        ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-400" 
                        : "bg-white/5 border-white/5 text-slate-400"
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className={`text-xs font-semibold leading-tight ${isSelected ? "text-white" : "text-slate-300"}`}>{type.label}</h4>
                      <p className="text-[10px] text-slate-500 mt-0.5 leading-normal">{type.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Tone Selectors */}
          <div className="glass-panel rounded-2xl p-5 border border-white/5 space-y-4">
            <label className="text-sm font-semibold text-slate-300">2. Deliverable Tone Preference</label>
            <div className="grid grid-cols-2 gap-2" id="tone-badges-grid">
              {tones.map((t) => {
                const isSelected = selectedTone === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => !isGenerating && setSelectedTone(t.id)}
                    className={`px-3 py-2.5 rounded-xl text-xs font-semibold capitalize border text-center transition-all duration-300 ${
                      isSelected 
                        ? `bg-gradient-to-r ${t.color} text-slate-950 border-transparent shadow-[0_0_15px_rgba(255,255,255,0.08)]` 
                        : "border-white/5 text-slate-400 hover:text-white hover:bg-white/5"
                    }`}
                    id={`tone-badge-${t.id}`}
                  >
                    {t.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Command execution launcher */}
          <div className="glass-panel p-4 rounded-2xl bg-gradient-to-tr from-indigo-950/40 to-purple-950/25 border border-white/5">
            <button
              onClick={handleSubmit}
              disabled={isGenerating || (!inputText.trim() && !attachedFile)}
              className={`w-full py-4 px-6 rounded-xl text-sm font-bold uppercase tracking-wider flex items-center justify-center space-x-2.5 transition-all duration-300 transform ${
                isGenerating || (!inputText.trim() && !attachedFile)
                  ? "bg-slate-900 border border-white/5 text-slate-600 cursor-not-allowed"
                  : "bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-400 hover:from-indigo-600 hover:to-cyan-500 text-white shadow-[0_0_20px_rgba(99,102,241,0.35)] hover:scale-[1.01] cursor-pointer"
              }`}
              id="generate-launch-button"
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 rounded-full border-2 border-slate-500 border-t-white animate-spin"></div>
                  <span>Analyzing Context...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-cyan-200" />
                  <span>Execute Analysis</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Voice / File Animated processing flow */}
      {isGenerating && (
        <div className="glass-panel rounded-2xl p-8 border border-cyan-500/20 bg-[#06041c]/80 relative overflow-hidden" id="active-generating-flow">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-cyan-500/10 to-transparent rounded-full blur-xl animate-pulse"></div>
          
          <div className="max-w-xl mx-auto space-y-6 text-center">
            {isAudioFile ? (
              <div className="space-y-1.5">
                <div className="flex items-center justify-center space-x-1.5 text-cyan-400 font-mono font-bold text-xs uppercase tracking-wider">
                  <span className="w-2 h-2 bg-cyan-400 rounded-full animate-ping"></span>
                  <span>Audio Waveform Pipeline</span>
                </div>
                <h4 className="text-xl font-bold font-display text-white">Extracting Audio Speech</h4>
              </div>
            ) : (
              <div className="space-y-1.5">
                <div className="text-indigo-400 font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-1">
                  <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-pulse"></span>
                  <span>AI Structural Core</span>
                </div>
                <h4 className="text-xl font-bold font-display text-white">Processing Document Information</h4>
              </div>
            )}

            {/* Simulated Workflow Pipeline */}
            <div className="relative py-4 flex items-center justify-between" id="pipeline-bar-stages">
              {/* Connecting line progress */}
              <div className="absolute left-6 right-6 top-1/2 h-[2px] bg-white/5 -translate-y-1/2 -z-10">
                <div 
                  className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-400 transition-all duration-500"
                  style={{
                    width: (() => {
                      const keys = ["analyze", "extract", "plan", "generate", "review", "export"];
                      const idx = keys.indexOf(activeGenerationStep);
                      if (idx < 0) return "0%";
                      return `${(idx / (keys.length - 1)) * 100}%`;
                    })()
                  }}
                ></div>
              </div>

              {/* Stage dots */}
              {[
                { label: "Analyze", key: "analyze", desc: "Agent 1: Analyzing uploaded content and detecting user intent..." },
                { label: "Extract Intel", key: "extract", desc: "Agent 2: Identifying important facts, dates, and definitions..." },
                { label: "Plan Layout", key: "plan", desc: "Agent 3: Selecting formatting structure and design layout..." },
                { label: "Generate", key: "generate", desc: "Agent 4: Authoring high-fidelity deliverables with specific tone..." },
                { label: "Review", key: "review", desc: "Agent 5: Validating grammar, removing brackets and fixing formatting..." },
                { label: "Export & Save", key: "export", desc: "Agent 6: Exporting deliverables and persisting to Firestore..." }
              ].map((stage, i, arr) => {
                const keys = arr.map(s => s.key);
                const currentIdx = keys.indexOf(activeGenerationStep);
                const isActive = currentIdx >= i;
                const isCurrent = activeGenerationStep === stage.key;
                return (
                  <div key={i} className="flex flex-col items-center space-y-2 relative flex-1">
                    <div className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all duration-300 ${
                      isCurrent 
                        ? "bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.4)] scale-110 animate-pulse" 
                        : isActive 
                          ? "bg-indigo-950/55 border-indigo-500/40 text-indigo-400" 
                          : "bg-slate-950/80 border-white/5 text-slate-600"
                    }`}>
                      {isActive && !isCurrent ? (
                        <CheckCircle className="w-4 h-4 text-indigo-300" />
                      ) : (
                        <span className="text-xs font-mono font-bold">{i+1}</span>
                      )}
                    </div>
                    <span className={`text-[10px] font-sans font-semibold tracking-wide transition-colors text-center max-w-[70px] leading-tight ${
                      isCurrent ? "text-cyan-400 font-bold" : isActive ? "text-slate-350" : "text-slate-600"
                    }`}>{stage.label}</span>
                  </div>
                );
              })}
            </div>

            <p className="text-slate-400 text-xs italic font-medium min-h-[1.5rem]">
              {(() => {
                const stepDescs: Record<string, string> = {
                  analyze: "Agent 1: Analyzing uploaded content and detecting user intent in raw streams...",
                  extract: "Agent 2: Running Information Extraction to extract deadlines, action items, and clear facts...",
                  plan: "Agent 3: Deciding structural formatting and laying out the blueprint outline...",
                  generate: "Agent 4: Directing Content Generation via Gemini multi-expert routing...",
                  review: "Agent 5: Reviewing quality metrics, validating outputs, and cleaning artifacts...",
                  export: "Agent 6: Packing deliverables for export options and synchronizing with Firestore..."
                };
                return stepDescs[activeGenerationStep] || "Processing pipeline initialization...";
              })()}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
