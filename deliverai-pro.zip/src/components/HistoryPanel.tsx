import { useState } from "react";
import { generateStyledPDF } from "../utils/pdfGenerator";
import { 
  Search, 
  Trash2, 
  ExternalLink,
  Filter,
  FileText,
  Mail,
  Users,
  BookOpen,
  Calendar,
  Clock,
  Download
} from "lucide-react";
import { Deliverable } from "../types";

interface HistoryPanelProps {
  deliverables: Deliverable[];
  onSelect: (item: Deliverable) => void;
  onDelete: (id: string) => void;
  searchQuery: string;
}

export default function HistoryPanel({ deliverables, onSelect, onDelete, searchQuery }: HistoryPanelProps) {
  const [localSearch, setLocalSearch] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [filterTone, setFilterTone] = useState<string>("all");

  const actualQuery = searchQuery || localSearch;

  // Filter deliverables based on searching query, type, and tone
  const filtered = deliverables.filter((item) => {
    const matchesQuery = !actualQuery 
      ? true 
      : item.summary.toLowerCase().includes(actualQuery.toLowerCase()) || 
        item.inputText.toLowerCase().includes(actualQuery.toLowerCase()) ||
        item.professional.toLowerCase().includes(actualQuery.toLowerCase());
    
    const matchesType = filterType === "all" ? true : item.deliverableType === filterType;
    const matchesTone = filterTone === "all" ? true : item.tone === filterTone;

    return matchesQuery && matchesType && matchesTone;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case "report": return <FileText className="w-4 h-4 text-indigo-400" />;
      case "email": return <Mail className="w-4 h-4 text-purple-400" />;
      case "meeting_minutes": return <Users className="w-4 h-4 text-cyan-400" />;
      case "study_notes": return <BookOpen className="w-4 h-4 text-emerald-400" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getLabel = (type: string) => {
    switch (type) {
      case "report": return "Professional Report";
      case "email": return "Professional Email";
      case "meeting_minutes": return "Meeting Minutes";
      case "study_notes": return "Study Notes";
      default: return type;
    }
  };

  const handleDownloadPDF = (item: Deliverable) => {
    try {
      generateStyledPDF(item, item.professional, "Professional");
    } catch (err) {
      console.error("PDF generation failed:", err);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="history-panel-container">
      {/* Search Header and Filters Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h3 className="text-xl font-bold font-display text-white">Deliverable Archives</h3>
          <p className="text-slate-400 text-xs mt-0.5">Manage, search, and export previously generated documents.</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Document Type Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-950/60 p-1.5 rounded-xl border border-white/10" id="filter-type-wrapper">
            <Filter className="w-3.5 h-3.5 text-slate-500 ml-1.5" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-transparent text-slate-350 text-xs py-1 px-2.5 outline-none font-semibold cursor-pointer border-none focus:ring-0 focus:border-none"
            >
              <option value="all" className="bg-[#030014] text-slate-300">All Formats</option>
              <option value="report" className="bg-[#030014] text-slate-300">Reports</option>
              <option value="email" className="bg-[#030014] text-slate-300">Emails</option>
              <option value="meeting_minutes" className="bg-[#030014] text-slate-300">Meeting Minutes</option>
              <option value="study_notes" className="bg-[#030014] text-slate-300">Study Notes</option>
            </select>
          </div>

          {/* Tone Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-950/60 p-1.5 rounded-xl border border-white/10" id="filter-tone-wrapper">
            <select
              value={filterTone}
              onChange={(e) => setFilterTone(e.target.value)}
              className="bg-transparent text-slate-350 text-xs py-1 px-2.5 outline-none font-semibold cursor-pointer border-none focus:ring-0 focus:border-none"
            >
              <option value="all" className="bg-[#030014] text-slate-300">All Tones</option>
              <option value="professional" className="bg-[#030014] text-slate-300">Professional</option>
              <option value="executive" className="bg-[#030014] text-slate-300">Executive</option>
              <option value="academic" className="bg-[#030014] text-slate-300">Academic</option>
              <option value="corporate" className="bg-[#030014] text-slate-300">Corporate</option>
              <option value="friendly" className="bg-[#030014] text-slate-300">Friendly</option>
              <option value="formal" className="bg-[#030014] text-slate-300">Formal</option>
            </select>
          </div>
        </div>
      </div>

      {/* Local search input for smaller screens when global header wasn't used */}
      {!searchQuery && (
        <div className="relative md:hidden w-full">
          <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Type search terms..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="w-full bg-slate-950/45 text-slate-200 pl-10 pr-4 py-2 text-xs rounded-xl border border-white/5 outline-none focus:border-indigo-500/50"
          />
        </div>
      )}

      {/* Archives Deliverables Cards Grid */}
      {filtered.length === 0 ? (
        <div className="glass-panel rounded-2xl p-16 text-center text-slate-500 space-y-3 border border-white/5">
          <Calendar className="w-12 h-12 mx-auto text-slate-650 animate-pulse" />
          <h4 className="font-bold text-slate-300 text-base">No matching records found</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">Try widening your key terms, setting filter fields to 'all', or generating fresh deliverables.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="history-cards-grid">
          {filtered.map((item) => {
            const qaScore = Math.round((item.qualityScores.readability + item.qualityScores.clarity) / 2);
            return (
              <div 
                key={item.id}
                onClick={() => onSelect(item)}
                className="glass-panel glass-panel-hover rounded-2xl p-5 border border-white/5 cursor-pointer relative group flex flex-col justify-between hover:-translate-y-0.5 transition-all duration-300"
                id={`history-card-${item.id}`}
              >
                <div>
                  {/* Top card metadata */}
                  <div className="flex items-center justify-between">
                    <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-white/5 border border-white/5 text-[10px] font-mono font-bold tracking-wide text-slate-450 uppercase leading-none">
                      {getIcon(item.deliverableType)}
                      <span className="text-slate-300">{getLabel(item.deliverableType)}</span>
                      <span>•</span>
                      <span className="text-indigo-400 capitalize">{item.tone}</span>
                    </div>

                    <div className="text-xs font-bold font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20 leading-none">
                      {qaScore}% QA
                    </div>
                  </div>

                  {/* Summary title */}
                  <h4 className="text-slate-100 font-bold font-display text-sm mt-4 leading-snug group-hover:text-white transition-colors">
                    {item.summary}
                  </h4>

                  {/* Snippet of input context */}
                  <p className="text-[11px] text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                    {item.inputText}
                  </p>
                </div>

                {/* Footer specs */}
                <div className="flex items-center justify-between border-t border-white/5 pt-3.5 mt-4 text-[10px] font-mono text-slate-450">
                  <div className="flex items-center space-x-3 text-slate-400">
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{item.productivityInsights.estimatedTimeSavedMinutes}m Saved</span>
                    </span>
                    <span>•</span>
                    <span className="truncate max-w-[120px]">
                      {new Date(item.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>

                  {/* Quick trigger buttons */}
                  <div className="flex items-center space-x-2.5" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => handleDownloadPDF(item)}
                      className="p-1.5 bg-white/5 rounded-lg border border-white/5 text-slate-400 hover:text-indigo-450 hover:border-indigo-500/30 transition-all"
                      title="Direct PDF Export"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => onSelect(item)}
                      className="p-1.5 bg-white/5 rounded-lg border border-white/5 text-slate-400 hover:text-cyan-400 hover:border-cyan-500/30 transition-all"
                      title="Reopen in Workspace"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                    
                    <button
                      onClick={() => onDelete(item.id)}
                      className="p-1.5 bg-white/5 rounded-lg border border-white/5 text-slate-400 hover:text-red-400 hover:border-red-500/30 transition-all"
                      title="Delete Record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
