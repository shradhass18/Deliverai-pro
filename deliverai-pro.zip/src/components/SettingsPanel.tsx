import { useState } from "react";
import { 
  Settings, 
  User, 
  Key, 
  HelpCircle,
  Sparkles,
  ShieldAlert,
  Save,
  CheckCircle,
  Database
} from "lucide-react";
import { UserProfile } from "../types";

interface SettingsPanelProps {
  profile: UserProfile;
  onUpdateProfile: (p: UserProfile) => void;
  firebaseStatus: {
    active: boolean;
    termsAccepted: boolean;
  };
  onTriggerFirebaseSetup: () => void;
  onLogout: () => void;
}

export default function SettingsPanel({ 
  profile, 
  onUpdateProfile,
  firebaseStatus,
  onTriggerFirebaseSetup,
  onLogout
}: SettingsPanelProps) {
  const [userName, setUserName] = useState(profile.name);
  const [userEmail, setUserEmail] = useState(profile.email);
  const [isSaved, setIsSaved] = useState(false);

  const handleSaveProfile = () => {
    // Save user profile details
    onUpdateProfile({
      name: userName,
      email: userEmail,
      avatarUrl: profile.avatarUrl
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="space-y-8 animate-fade-in" id="settings-panel">
      {/* Title Header */}
      <div className="border-b border-white/10 pb-4">
        <h3 className="text-xl font-bold font-display text-white">Workspace Configuration</h3>
        <p className="text-slate-400 text-xs mt-0.5">Customize your editor workspace profile and configure sync models.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Side: Profile options (2 columns) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass-panel p-6 rounded-2xl border border-white/5 space-y-6">
            <div className="flex items-center space-x-2 border-b border-white/5 pb-3">
              <User className="w-4 h-4 text-cyan-400" />
              <h4 className="text-sm font-bold text-white font-display">User Profile</h4>
            </div>

            <div className="space-y-4" id="profile-management-fields">
              {/* Profile image placeholder */}
              <div className="flex items-center space-x-4">
                <img
                  src={profile.avatarUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"}
                  alt={profile.name}
                  className="w-14 h-14 rounded-xl object-cover ring-2 ring-indigo-500/40"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h5 className="text-xs font-semibold text-slate-200">User Identification Image</h5>
                  <p className="text-[10px] text-slate-500 leading-normal mt-0.5">Linked directly to your local workspace account credentials.</p>
                </div>
              </div>

              {/* Name Field */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-400">Full Name</label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full bg-slate-950/45 text-slate-200 p-3 text-xs rounded-xl border border-white/5 outline-none focus:border-indigo-500/50"
                  placeholder="Enter full name"
                />
              </div>

              {/* Email Field */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-400">Work Email Address</label>
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  className="w-full bg-slate-950/45 text-slate-200 p-3 text-xs rounded-xl border border-white/5 outline-none focus:border-indigo-500/50"
                  placeholder="Enter work email"
                />
              </div>

              {/* Save trigger */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  onClick={handleSaveProfile}
                  className="py-2.5 px-4 rounded-xl text-xs font-bold uppercase tracking-wider bg-indigo-505 bg-indigo-600 hover:bg-indigo-700 text-white transition-all flex items-center space-x-2 cursor-pointer"
                  id="save-profile-btn"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Update Profile Details</span>
                </button>

                <button
                  onClick={onLogout}
                  className="py-2.5 px-4 rounded-xl text-xs font-bold uppercase tracking-wider bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-300 transition-all flex items-center space-x-2 cursor-pointer"
                  id="logout-btn"
                >
                  <span>Sign Out Account</span>
                </button>

                {isSaved && (
                  <span className="text-xs text-emerald-400 font-semibold flex items-center space-x-1 animate-fade-in">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Saved locally successfully!</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Cloud Database Integration Status */}
          <div className="glass-panel p-6 rounded-2xl border border-white/5 space-y-6">
            <div className="flex items-center space-x-2 border-b border-white/5 pb-3">
              <Database className="w-4 h-4 text-purple-400 animate-pulse" />
              <h4 className="text-sm font-bold text-white font-display">Cloud Persistence Status</h4>
            </div>

            <div className="space-y-4">
              <p className="text-xs text-slate-400 leading-relaxed">
                By default, DeliverAI Pro synchronizes deliverables, inputs, and export logs to an offline-first **local index cache** inside your browser. For long-term durable cloud security and sharing across platforms, you can provision deep cloud storage.
              </p>

              {firebaseStatus.active ? (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-start space-x-3 text-xs">
                  <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold leading-normal text-white">Firestore Cloud Database Active</h5>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      All created deliverables are safely stored in Firestore.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/25 text-indigo-400 flex flex-col space-y-3 md:flex-row md:space-y-0 md:items-start md:space-x-4 text-xs">
                  <ShieldAlert className="w-4 h-4 lg:w-5 lg:h-5 shrink-0 mt-0.5 text-indigo-400" />
                  <div className="flex-1">
                    <h5 className="font-bold leading-normal text-slate-100">Durable Cloud Sync Pending</h5>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      To activate persistent cloud database storage via Google Firestore, click to request Firebase provisioning. It establishes sandboxed data structures and secure rules immediately.
                    </p>
                    <button
                      onClick={onTriggerFirebaseSetup}
                      className="mt-3.5 py-2 px-3.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-indigo-500 text-white hover:bg-indigo-600 transition-all shadow-[0_0_15px_rgba(99,102,241,0.3)] flex items-center space-x-1.5"
                      id="request-cloud-btn"
                    >
                      <span>Enable Cloud Storage</span>
                      <Sparkles className="w-3 h-3 text-cyan-200" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Gemini Secrets documentation (1 column) */}
        <div className="space-y-6 text-slate-400">
          <div className="glass-panel p-6 rounded-2xl border border-white/5 space-y-4">
            <div className="flex items-center space-x-2 border-b border-white/5 pb-2">
              <Key className="w-4 h-4 text-cyan-400" />
              <h4 className="text-sm font-bold text-white font-display">API Key & Secrets</h4>
            </div>

            <p className="text-xs leading-relaxed">
              DeliverAI Pro processes content under a secure full-stack proxy architecture. Private API keys (including your **GEMINI_API_KEY**) are kept hidden from the browser.
            </p>

            <div className="p-4 rounded-xl bg-white/5 border border-white/5 text-[11px] leading-relaxed">
              <span className="font-bold text-slate-200 uppercase tracking-wide flex items-center space-x-1 mb-1 font-mono">
                <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span>
                <span>Active Model</span>
              </span>
              <p className="font-mono text-cyan-400">gemini-3.5-flash</p>
            </div>

            <div className="pt-2 flex items-start space-x-2 text-xs">
              <HelpCircle className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
              <p className="text-slate-500 leading-normal">
                To update your Gemini secret keys, click the **Settings &gt; Secrets** panel in the Google AI Studio container menu. Key changes apply instantly to the Express API backend.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
