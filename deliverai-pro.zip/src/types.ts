export interface Deliverable {
  id: string;
  userId?: string;
  inputText: string;
  deliverableType: 'report' | 'email' | 'meeting_minutes' | 'study_notes';
  tone: 'professional' | 'executive' | 'academic' | 'corporate' | 'friendly' | 'formal';
  file?: {
    name: string;
    type: string;
    size: number;
    data: string; // base64 string
  };
  professional: string; // Markdown
  executive: string; // Markdown
  academic: string; // Markdown
  qualityScores: {
    readability: number;
    professionalism: number;
    completeness: number;
    clarity: number;
  };
  productivityInsights: {
    estimatedTimeSavedMinutes: number;
    tasksIdentified: string[];
    deadlinesFound: string[];
    decisionsExtracted: string[];
  };
  summary: string;
  createdAt: string; // ISO String
}

export type ActiveTab = 'dashboard' | 'generate' | 'history' | 'analytics' | 'settings';

export interface UserProfile {
  name: string;
  email: string;
  avatarUrl?: string;
}
